<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "localhost");
define("DB_NAME", "entregestos");
define("DB_USER", "root");
define("DB_PASSWORD", "bancodedados");   

define("AMB_DEV", true);

define("BASE_URL", "http://localhost/entre_gestos/entre_gestos_v2");
