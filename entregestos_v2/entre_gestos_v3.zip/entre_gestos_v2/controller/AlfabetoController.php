<?php

require_once(__DIR__ . "/../dao/AlfabetoDAO.php");

class AlfabetoController
{
    public function listar()
    {
        $dao = new AlfabetoDAO();
        return $dao->list();
    }
}
