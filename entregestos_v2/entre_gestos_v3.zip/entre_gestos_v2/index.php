<?php
//Redireciona para o login
header("location: ./view/auth/login.php");
