<?php
require_once(__DIR__ . "/../../controller/AuthController.php");
$auth = new AuthController();
$auth->exigirLogin();

require_once(__DIR__ . "/../../controller/LicaoController.php");

$controller = new LicaoController();

$licaoId = $_GET['id'] ?? null;
if (!$licaoId) {
    header("Location: trilha.php");
    exit;
}

$licao   = $controller->buscarPorId((int) $licaoId);
if (!$licao) {
    die("Lição não encontrada.");
}

$resultado = $controller->buscarTodasQuestoes((int) $licaoId);

$q_idx = isset($_GET['q_idx']) ? (int)$_GET['q_idx'] : 0;
$totalQuestoes = count($resultado);

if ($q_idx < $totalQuestoes) {
    $questaoData = $resultado[$q_idx];
    $questao = $questaoData['questao'];
    $tipo = $questao->getTipo();
    $opcoes = $questaoData['opcoes'] ?? [];
    $pares = $questaoData['pares'] ?? [];
    $respostaCorreta = $questaoData['resposta_correta'] ?? '';
    $progresso = ($totalQuestoes > 0) ? ($q_idx / $totalQuestoes) * 100 : 0;
} else {
    $questao = null;
    $opcoes = [];
    $progresso = 100;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lição - <?= htmlspecialchars($licao->getTitulo()) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --green-main: #58cc02;
            --green-shadow: #58a700;
            --blue-main: #1cb0f6;
            --blue-shadow: #1899d6;
        }
        * { box-sizing: border-box; font-family: 'Nunito', sans-serif; }
        body { margin: 0; padding: 20px; background-color: #fff; color: #3c3c3c; display: flex; flex-direction: column; align-items: center; min-height: 100vh; }

        .header { width: 100%; max-width: 600px; display: flex; align-items: center; justify-content: space-between; margin-bottom: 40px; }
        .close-btn { font-size: 24px; text-decoration: none; color: #afafaf; font-weight: bold; }
        .progress-bar { flex: 1; height: 16px; background: #e5e5e5; border-radius: 10px; margin: 0 20px; position: relative; }
        .progress-fill { position: absolute; left: 0; top: 0; height: 100%; background: var(--green-main); border-radius: 10px; width: 20%; transition: width 0.3s; }

        .question-container { width: 100%; max-width: 600px; flex: 1; display: flex; flex-direction: column; padding-bottom: 120px; }
        .title    { font-size: 28px; font-weight: 800; margin-bottom: 30px; }
        .enunciado { font-size: 20px; font-weight: 700; margin-bottom: 30px; color: #333; }

        .options-grid { display: grid; gap: 15px; }
        .option-btn {
            padding: 20px; border: 2px solid #e5e5e5; border-radius: 16px;
            background: white; font-size: 18px; font-weight: 700; color: #3c3c3c;
            cursor: pointer; text-align: left; transition: all 0.1s;
            box-shadow: 0 4px 0 #e5e5e5;
        }
        .option-btn:active  { transform: translateY(4px); box-shadow: 0 0 0 transparent; }
        .option-btn.selected { border-color: var(--blue-main); background: #ddf4ff; color: var(--blue-main); box-shadow: 0 4px 0 var(--blue-shadow); }
        .option-btn.correct  { border-color: var(--green-main); background: #d7ffb8; color: var(--green-shadow); box-shadow: 0 4px 0 var(--green-shadow); pointer-events: none; }
        .option-btn.wrong    { border-color: #ff4b4b; background: #ffdfe0; color: #ea2b2b; box-shadow: 0 4px 0 #ea2b2b; pointer-events: none; }

        .input-aberta { width: 100%; padding: 20px; font-size: 20px; font-weight: 700; color: #3c3c3c; border: 2px solid #e5e5e5; border-radius: 16px; outline: none; transition: border-color 0.2s; box-shadow: 0 4px 0 #e5e5e5; }
        .input-aberta:focus { border-color: var(--blue-main); box-shadow: 0 4px 0 var(--blue-shadow); }

        .assoc-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 15px; gap: 10px; }
        .assoc-left { flex: 1; padding: 15px; border: 2px solid #e5e5e5; border-radius: 12px; background: white; font-weight: 700; color: #3c3c3c; box-shadow: 0 4px 0 #e5e5e5; }
        .assoc-right { flex: 1; padding: 15px; border: 2px solid #e5e5e5; border-radius: 12px; font-weight: 700; color: #3c3c3c; cursor: pointer; outline: none; background: white; box-shadow: 0 4px 0 #e5e5e5; }
        .assoc-right:focus { border-color: var(--blue-main); }

        .footer { width: 100%; position: fixed; bottom: 0; left: 0; padding: 20px; background: white; border-top: 2px solid #e5e5e5; display: flex; justify-content: center; transition: background-color 0.3s, border-color 0.3s; z-index: 10; }
        .footer-content { width: 100%; max-width: 600px; display: flex; justify-content: space-between; align-items: center; }
        .check-btn {
            padding: 15px 30px; border-radius: 16px; border: none; font-size: 18px; font-weight: bold;
            background: #e5e5e5; color: #afafaf; cursor: not-allowed; transition: all 0.2s;
        }
        .check-btn.active { background: var(--green-main); color: white; box-shadow: 0 4px 0 var(--green-shadow); cursor: pointer; }
        .check-btn.active:active { transform: translateY(4px); box-shadow: 0 0 0 transparent; }
    </style>
</head>
<body>
    <div class="header">
        <a href="trilha.php" class="close-btn">✖</a>
        <div class="progress-bar"><div class="progress-fill" style="width: <?= $progresso ?>%;"></div></div>
        <div style="color: #ff4b4b; font-weight: 800; font-size: 20px;">❤️ 5</div>
    </div>

    <div class="question-container">
        <?php if ($questao): ?>
            <div class="title">Traduza esta frase</div>
            <div class="enunciado"><?= htmlspecialchars($questao->getEnunciado()) ?></div>

            <?php if ($tipo === 'multipla_escolha'): ?>
                <div class="options-grid" id="options">
                    <?php foreach ($opcoes as $op): ?>
                        <button class="option-btn"
                                data-correct="<?= $op->getEstaCorreta() ? '1' : '0' ?>"
                                onclick="selectOption(this)">
                            <?= htmlspecialchars($op->getConteudo()) ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            <?php elseif ($tipo === 'aberta'): ?>
                <input type="text" id="resposta_aberta" class="input-aberta" placeholder="Digite sua resposta..." oninput="checkInput()">
                <input type="hidden" id="correct_answer" value="<?= htmlspecialchars($respostaCorreta) ?>">
            <?php elseif ($tipo === 'associacao'): 
                $direitos = array_column($pares, 'direito');
                shuffle($direitos);
            ?>
                <div id="assoc-container">
                    <?php foreach ($pares as $idx => $par): ?>
                        <div class="assoc-row" data-correct="<?= htmlspecialchars($par['direito']) ?>">
                            <div class="assoc-left"><?= htmlspecialchars($par['esquerdo']) ?></div>
                            <select class="assoc-right" onchange="checkAssoc()">
                                <option value="">-- Escolha --</option>
                                <?php foreach($direitos as $dir): ?>
                                    <option value="<?= htmlspecialchars($dir) ?>"><?= htmlspecialchars($dir) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="title">Parabéns! 🎉</div>
            <div class="enunciado">Você concluiu esta lição. Continue sua jornada!</div>
        <?php endif; ?>
    </div>

    <div class="footer" id="footer">
        <div class="footer-content">
            <div id="feedback" style="font-size: 22px; font-weight: 900; display: none;"></div>
            <?php if ($questao): ?>
                <button class="check-btn" id="checkBtn" onclick="checkAnswer()">VERIFICAR</button>
            <?php else: ?>
                <button class="check-btn active" onclick="window.location.href='concluir_licao.php?id=<?= $licao->getId() ?>'">CONTINUAR</button>
            <?php endif; ?>
        </div>
    </div>

    <script>
        const tipoQuestao = "<?= isset($tipo) ? $tipo : '' ?>";
        let selectedBtn = null;

        function selectOption(btn) {
            document.querySelectorAll('.option-btn').forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
            selectedBtn = btn;
            document.getElementById('checkBtn').classList.add('active');
            document.getElementById('checkBtn').disabled = false;
        }

        function checkInput() {
            const val = document.getElementById('resposta_aberta').value.trim();
            const btn = document.getElementById('checkBtn');
            if (val.length > 0) {
                btn.classList.add('active');
                btn.disabled = false;
            } else {
                btn.classList.remove('active');
                btn.disabled = true;
            }
        }

        function checkAssoc() {
            const selects = document.querySelectorAll('.assoc-right');
            let allFilled = true;
            selects.forEach(s => {
                if (s.value === "") allFilled = false;
            });
            const btn = document.getElementById('checkBtn');
            if (allFilled) {
                btn.classList.add('active');
                btn.disabled = false;
            } else {
                btn.classList.remove('active');
                btn.disabled = true;
            }
        }

        function checkAnswer() {
            const checkBtn  = document.getElementById('checkBtn');
            if (checkBtn.innerText === 'CONTINUAR' || checkBtn.innerText === 'PRÓXIMA') {
                checkBtn.onclick();
                return;
            }
            if (checkBtn.disabled) return;

            let isCorrect = false;

            if (tipoQuestao === 'multipla_escolha') {
                if (!selectedBtn) return;
                isCorrect = selectedBtn.getAttribute('data-correct') === '1';
                if (isCorrect) {
                    selectedBtn.classList.add('correct');
                    selectedBtn.classList.remove('selected');
                } else {
                    selectedBtn.classList.add('wrong');
                    selectedBtn.classList.remove('selected');
                    setTimeout(() => {
                        selectedBtn.classList.remove('wrong');
                        selectedBtn = null;
                        checkBtn.classList.remove('active');
                    }, 2000);
                }
            } else if (tipoQuestao === 'aberta') {
                const answer = document.getElementById('resposta_aberta').value.trim().toLowerCase();
                const correct = document.getElementById('correct_answer').value.trim().toLowerCase();
                isCorrect = (answer === correct);
                const inputEl = document.getElementById('resposta_aberta');
                if (isCorrect) {
                    inputEl.style.borderColor = 'var(--green-main)';
                    inputEl.style.color = 'var(--green-shadow)';
                    inputEl.disabled = true;
                } else {
                    inputEl.style.borderColor = '#ea2b2b';
                    inputEl.style.color = '#ea2b2b';
                    setTimeout(() => {
                        inputEl.style.borderColor = '#e5e5e5';
                        inputEl.style.color = '#3c3c3c';
                        checkBtn.classList.remove('active');
                        checkBtn.disabled = true;
                    }, 2000);
                }
            } else if (tipoQuestao === 'associacao') {
                const rows = document.querySelectorAll('.assoc-row');
                isCorrect = true;
                rows.forEach(row => {
                    const select = row.querySelector('.assoc-right');
                    const correctVal = row.getAttribute('data-correct');
                    if (select.value !== correctVal) {
                        isCorrect = false;
                        select.style.borderColor = '#ea2b2b';
                        select.style.color = '#ea2b2b';
                        setTimeout(() => {
                            select.style.borderColor = '#e5e5e5';
                            select.style.color = '#3c3c3c';
                            select.value = "";
                            checkBtn.classList.remove('active');
                            checkBtn.disabled = true;
                        }, 2000);
                    } else {
                        select.style.borderColor = 'var(--green-main)';
                        select.style.color = 'var(--green-shadow)';
                        select.disabled = true;
                    }
                });
            }

            const feedback  = document.getElementById('feedback');
            const footer    = document.getElementById('footer');

            if (isCorrect) {
                footer.style.backgroundColor = '#d7ffb8';
                footer.style.borderColor     = '#d7ffb8';
                feedback.style.display       = 'block';
                feedback.style.color         = 'var(--green-shadow)';
                feedback.innerText           = '✓ Mandou bem!';
                
                <?php if (isset($q_idx) && isset($totalQuestoes) && $q_idx + 1 < $totalQuestoes): ?>
                    checkBtn.innerText = 'PRÓXIMA';
                    checkBtn.onclick = function() {
                        window.location.href = 'licao.php?id=<?= $licao->getId() ?>&q_idx=<?= $q_idx + 1 ?>';
                    };
                <?php else: ?>
                    checkBtn.innerText = 'CONTINUAR';
                    checkBtn.onclick = function() {
                        window.location.href = 'concluir_licao.php?id=<?= $licao->getId() ?>';
                    };
                <?php endif; ?>
                
                document.querySelector('.progress-fill').style.width = '<?= ($totalQuestoes > 0) ? (($q_idx + 1) / $totalQuestoes) * 100 : 100 ?>%';
            } else {
                footer.style.backgroundColor = '#ffdfe0';
                footer.style.borderColor     = '#ffdfe0';
                feedback.style.display       = 'block';
                feedback.style.color         = '#ea2b2b';
                feedback.innerText           = '✗ Incorreto. Tente novamente!';
                setTimeout(() => {
                    footer.style.backgroundColor = 'white';
                    footer.style.borderColor     = '#e5e5e5';
                    feedback.style.display       = 'none';
                }, 2000);
            }
        }
    </script>
</body>
</html>
