<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once(__DIR__ . "/../../util/config.php");


require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/LicaoController.php");
require_once(__DIR__ . "/../../controller/SecaoController.php");
require_once(__DIR__ . "/../../dao/ProgressoDAO.php");

$authCtrl = new AuthController();
$authCtrl->exigirLogin();
$alunoId = $authCtrl->getUsuarioLogadoId();
$usuarioLogado = $authCtrl->getUsuarioLogado();

$licaoCtrl = new LicaoController();
$secaoCtrl = new SecaoController();
$progressoDao = new ProgressoDAO();

$licoesConcluidas = $progressoDao->getLicoesConcluidas($alunoId);

// Get all lessons and sections
$todasLicoes = $licaoCtrl->listar();
$secoes = $secaoCtrl->listar();

// Group lessons by section
$trilha = [];
foreach ($secoes as $secao) {
    $trilha[$secao->getId()] = [
        'secao' => $secao,
        'licoes' => []
    ];
}

$isLocked = false;
foreach ($todasLicoes as $licao) {
    $licaoId = $licao->getId();
    $completada = in_array($licaoId, $licoesConcluidas);

    if (!$isLocked) {
        if (!$completada) {
            $status = 'lesson-current';
            $isLocked = true; // A partir daqui, as próximas estarão bloqueadas
        } else {
            $status = 'lesson-unlocked';
        }
    } else {
        $status = 'lesson-locked';
    }

    $licao->status_calculado = $status;

    if (isset($trilha[$licao->getSecaoId()])) {
        $trilha[$licao->getSecaoId()]['licoes'][] = $licao;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aprender LIBRAS - EntreGestos</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #fdfaf6;
            --sidebar-bg: #ffffff;
            --text-main: #3c3c3c;
            --text-muted: #afafaf;
            --green-main: #58cc02;
            --green-shadow: #58a700;
            --blue-main: #1cb0f6;
            --blue-shadow: #1899d6;
            --locked-bg: #ffffff;
            --locked-shadow: #d8c3a5;
            --locked-border: #d8c3a5;
            --section-bg: #58cc02;
            --timeline-color: #d8c3a5;
            --card-brown: #8c7355;
            --card-brown-light: #b59b7b;
            --card-yellow: #eef314;
            --card-yellow-shadow: #d4d812;
            --card-white: #ffffff;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Nunito', sans-serif;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            border-right: 2px solid #e5e5e5;
            padding: 20px;
            position: fixed;
            height: 100vh;
            display: flex;
            flex-direction: column;
            background: var(--sidebar-bg);
            z-index: 100;
        }

        .logo {
            font-size: 28px;
            font-weight: 900;
            color: var(--green-main);
            margin-bottom: 40px;
            text-align: center;
            letter-spacing: -1px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            margin-bottom: 10px;
            color: var(--text-muted);
            font-weight: 700;
            font-size: 17px;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.2s;
            cursor: pointer;
        }

        .nav-link:hover {
            background-color: #f7f7f7;
        }

        .nav-link.active {
            color: var(--blue-main);
            background-color: #ddf4ff;
            border: 2px solid #ddf4ff;
        }

        .nav-icon {
            width: 30px;
            height: 30px;
            margin-right: 15px;
            background-color: #ddd;
            border-radius: 8px;
            display: inline-block;
        }

        .active .nav-icon {
            background-color: var(--blue-main);
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            display: flex;
            justify-content: center;
            padding: 40px 20px;
        }

        .path-container {
            width: 100%;
            max-width: 700px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* Section Header */
        .section-header {
            width: 100%;
            background-color: var(--card-white);
            color: var(--card-brown);
            padding: 25px 30px;
            border-radius: 20px;
            margin-bottom: 50px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border: 2px solid var(--border);
            text-align: center;
        }

        .section-header h2 {
            font-size: 24px;
            font-weight: 900;
            margin-bottom: 5px;
            color: var(--card-brown);
        }

        .section-header p {
            font-size: 16px;
            font-weight: 700;
            color: var(--card-brown-light);
        }

        /* Timeline Layout */
        .timeline {
            position: relative;
            width: 100%;
            padding: 20px 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .timeline-line {
            position: absolute;
            left: 50%;
            top: 0;
            transform: translateX(-50%);
            width: 4px;
            height: 100%;
            background-color: var(--timeline-color);
            z-index: 1;
        }

        .timeline-item {
            position: relative;
            width: 100%;
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            z-index: 2;
        }

        /* Alternate sides */
        .timeline-item:nth-child(odd) {
            justify-content: flex-start;
        }

        .timeline-item:nth-child(odd) .timeline-card {
            margin-right: 55%;
            transform: translateX(calc(100% - 20px));
            /* Push to left side of the line */
            margin-left: auto;
            transform: none;
            /* We use a trick with margins */
            width: calc(50% - 40px);
        }

        .timeline-item:nth-child(even) {
            justify-content: flex-end;
        }

        .timeline-item:nth-child(even) .timeline-card {
            margin-left: 55%;
            transform: none;
            width: calc(50% - 40px);
        }

        /* overriding alignment logic for clarity */
        .item-left {
            justify-content: flex-start !important;
        }

        .item-right {
            justify-content: flex-end !important;
        }

        .item-left .timeline-card {
            width: calc(50% - 40px);
            margin-left: 0;
            margin-right: 40px;
        }

        .item-right .timeline-card {
            width: calc(50% - 40px);
            margin-right: 0;
            margin-left: 40px;
        }

        .timeline-dot {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background-color: var(--card-brown-light);
            border: 3px solid var(--bg-color);
            z-index: 3;
            transition: all 0.3s;
        }

        /* Card Styles */
        .timeline-card {
            background: var(--card-white);
            border-radius: 16px;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            border: 2px solid var(--card-brown-light);
            box-shadow: 0 4px 0 var(--card-brown-light);
            cursor: pointer;
            text-align: left;
            transition: transform 0.1s, box-shadow 0.1s;
            text-decoration: none;
            color: var(--text-main);
        }

        .timeline-card:active {
            transform: translateY(4px);
            box-shadow: 0 0 0 transparent;
        }

        /* Locked State */
        .lesson-locked .timeline-card {
            background: var(--locked-bg);
            border-color: var(--locked-border);
            box-shadow: 0 4px 0 var(--locked-shadow);
            opacity: 0.7;
            cursor: not-allowed;
        }

        .lesson-locked .timeline-card:active {
            transform: none;
            box-shadow: 0 4px 0 var(--locked-shadow) !important;
        }

        .lesson-locked .timeline-dot {
            background-color: var(--locked-border);
        }

        /* Unlocked State */
        .lesson-unlocked .timeline-card {
            border-color: var(--card-brown);
            box-shadow: 0 4px 0 var(--card-brown);
        }

        .lesson-unlocked .timeline-dot {
            background-color: var(--card-brown);
        }

        /* Current State */
        .lesson-current .timeline-card {
            background: var(--card-yellow);
            border-color: var(--card-yellow);
            box-shadow: 0 4px 0 var(--card-yellow-shadow);
        }

        .lesson-current .timeline-dot {
            background-color: var(--card-yellow);
            box-shadow: 0 0 0 4px rgba(238, 243, 20, 0.4);
            border-color: var(--card-yellow-shadow);
        }

        /* Card Internals */
        .card-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(140, 115, 85, 0.1);
            color: var(--card-brown);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-right: 15px;
            flex-shrink: 0;
        }

        .lesson-current .card-icon {
            background: rgba(255, 255, 255, 0.4);
            color: #8c7355;
        }

        .lesson-locked .card-icon {
            background: rgba(216, 195, 165, 0.2);
            color: var(--locked-border);
        }

        .card-content {
            flex: 1;
        }

        .card-title {
            font-size: 16px;
            font-weight: 800;
            color: var(--card-brown);
            margin-bottom: 2px;
        }

        .lesson-locked .card-title {
            color: var(--card-brown-light);
        }

        .card-subtitle {
            font-size: 13px;
            font-weight: 700;
            color: var(--card-brown-light);
            line-height: 1.2;
        }

        .card-stars {
            color: #ffc800;
            font-size: 14px;
            margin-left: 10px;
            letter-spacing: 2px;
        }

        .lesson-locked .card-stars {
            color: #e5e5e5;
        }

        @media (max-width: 768px) {
            .sidebar {
                bottom: 0;
                top: auto;
                width: 100%;
                height: 80px;
                flex-direction: row;
                justify-content: space-around;
                border-right: none;
                border-top: 2px solid #e5e5e5;
                padding: 10px;
                z-index: 1000;
            }

            .logo {
                display: none;
            }

            .nav-link {
                padding: 10px;
                margin: 0;
                flex-direction: column;
                font-size: 12px;
            }

            .nav-icon {
                margin: 0 0 5px 0;
            }

            .main-content {
                margin-left: 0;
                margin-bottom: 80px;
                padding: 20px 10px;
            }

            /* Responsive timeline */
            .timeline-line {
                left: 20px;
            }

            .timeline-item.item-left,
            .timeline-item.item-right {
                justify-content: flex-start !important;
                padding-left: 40px;
            }

            .item-left .timeline-card,
            .item-right .timeline-card {
                width: 100%;
                margin: 0;
            }

            .timeline-dot {
                left: 20px;
            }
        }
    </style>
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">EntreGestos</div>

        <div style="text-align: center; margin-bottom: 30px;">
            <div style="font-weight: 900; color: var(--text-main); font-size: 18px;">
                Olá, <?= htmlspecialchars(explode(' ', $usuarioLogado['nome_completo'])[0]) ?>!
            </div>
            <div style="font-size: 14px; font-weight: 700; color: var(--text-muted); text-transform: capitalize;">
                <?= htmlspecialchars($usuarioLogado['perfil']) ?>
            </div>
        </div>

        <a href="#" class="nav-link active">
            <span class="nav-icon"></span> Aprender
        </a>
        <a href="#" class="nav-link">
            <span class="nav-icon" style="background:#ffc800;"></span> Conquistas
        </a>
        <a href="#" class="nav-link">
            <span class="nav-icon" style="background:#ff4b4b;"></span> Perfil
        </a>

        <a href="<?= BASE_URL ?>/view/app/alfabeto.php" class="nav-link">
            <span class="nav-icon" style="background:#ff4b4b;"></span> Alfabeto
        </a>

        <?php if ($usuarioLogado['perfil'] === 'administrador'): ?>
            <a href="../admin/dashboard.php" class="nav-link">
                <span class="nav-icon" style="background:#777;"></span> Admin (CRUDs)
            </a>
        <?php endif; ?>

        <a href="../auth/logout.php" class="nav-link" style="margin-top: auto; color: var(--red-main);">
            <span class="nav-icon" style="background:#ffdfe0;"></span> Sair
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="path-container">

            <?php
            foreach ($trilha as $item):
                $secao = $item['secao'];
                $licoes = $item['licoes'];
            ?>

                <div class="section-header">
                    <h2>Unidade <?= $secao->getOrdem() ?></h2>
                    <p><?= htmlspecialchars($secao->getTitulo()) ?></p>
                </div>

                <div class="timeline">
                    <div class="timeline-line"></div>

                    <?php foreach ($licoes as $index => $licao):
                        $btnClass = $licao->status_calculado; // lesson-locked, lesson-unlocked, lesson-current
                        $locked = ($btnClass === 'lesson-locked');

                        // Alterna entre esquerda e direita
                        $sideClass = ($index % 2 == 0) ? 'item-left' : 'item-right';
                    ?>

                        <div class="timeline-item <?= $sideClass ?> <?= $btnClass ?>">
                            <div class="timeline-dot"></div>

                            <button class="timeline-card"
                                <?= $locked && $btnClass !== 'lesson-current' ? 'disabled' : '' ?>
                                onclick="if(!this.disabled) window.location.href='licao.php?id=<?= $licao->getId() ?>'">

                                <div class="card-icon">
                                    <?php if ($btnClass === 'lesson-locked'): ?>
                                        🔒
                                    <?php elseif ($btnClass === 'lesson-current'): ?>
                                        ▶
                                    <?php else: ?>
                                        ★
                                    <?php endif; ?>
                                </div>

                                <div class="card-content">
                                    <div class="card-title">Lição <?= $licao->getOrdem() ?></div>
                                    <div class="card-subtitle"><?= htmlspecialchars($licao->getTitulo()) ?></div>
                                </div>

                                <div class="card-stars">
                                    <?php if ($btnClass === 'lesson-unlocked'): ?>
                                        ★★★
                                    <?php elseif ($btnClass === 'lesson-current'): ?>
                                        ☆☆☆
                                    <?php else: ?>

                                    <?php endif; ?>
                                </div>
                            </button>
                        </div>

                    <?php endforeach; ?>
                </div>

            <?php endforeach; ?>

            <?php if (empty($trilha)): ?>
                <div style="text-align: center; color: var(--text-muted); margin-top: 50px;">
                    <h2>Nenhuma lição cadastrada ainda!</h2>
                    <p>Vá no Admin e crie Cursos, Seções e Lições.</p>
                </div>
            <?php endif; ?>

        </div>
    </div>

</body>

</html>