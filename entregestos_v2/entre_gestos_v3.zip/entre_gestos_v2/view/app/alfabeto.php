<?php

require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/AlfabetoController.php");

$authCtrl = new AuthController();
$authCtrl->exigirLogin();
$usuarioLogado = $authCtrl->getUsuarioLogado();

$alfabetoCtrl = new AlfabetoController();
$letras = $alfabetoCtrl->listar();

/**
 * Créditos das imagens (opcional). Edite com os créditos
 * reais das fontes/canais de onde as imagens foram tiradas.
 */
$creditos = [
    ["nome" => "Nome do Canal/Fonte 1", "url" => "#"],
    ["nome" => "Nome do Canal/Fonte 2", "url" => "#"],
];
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alfabeto em Libras - EntreGestos</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #fdfaf6;
            --text-main: #3c3c3c;
            --text-muted: #afafaf;
            --border: #e5e5e5;
            --green-main: #58cc02;
            --green-shadow: #58a700;
            --blue-main: #1cb0f6;
            --blue-shadow: #1899d6;
            --card-brown: #8c7355;
            --card-white: #ffffff;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Nunito', sans-serif;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            min-height: 100vh;
        }

        /* ===== HEADER ===== */
        .app-header {
            width: 100%;
            background: var(--card-white);
            border-bottom: 2px solid var(--border);
            padding: 18px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 50;
        }

        .app-header .logo {
            font-size: 22px;
            font-weight: 900;
            color: var(--green-main);
            letter-spacing: -0.5px;
            text-decoration: none;
        }

        .app-header h1 {
            font-size: 20px;
            font-weight: 800;
            color: var(--text-main);
        }

        .back-link {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 18px;
            color: var(--green-main);
            font-weight: 800;
            font-size: 14px;
            text-decoration: none;
            border-radius: 12px;
            border: 2px solid var(--green-main);
            background: #f0fff0;
            transition: background 0.15s;
        }

        .back-link:hover {
            background: #d7ffb8;
        }

        /* ===== MAIN ===== */
        .main-content {
            max-width: 1100px;
            margin: 0 auto;
            padding: 40px 20px 60px;
        }

        .page-intro {
            text-align: center;
            margin-bottom: 35px;
        }

        .page-intro h2 {
            font-size: 28px;
            font-weight: 900;
            margin-bottom: 8px;
        }

        .page-intro p {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-muted);
        }

        /* ===== GRID DE LETRAS ===== */
        .alfabeto-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 22px;
        }

        @media (max-width: 900px) {
            .alfabeto-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 600px) {
            .alfabeto-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 14px;
            }
        }

        .letra-card {
            background: var(--card-white);
            border: 2px solid var(--border);
            border-radius: 18px;
            box-shadow: 0 4px 0 var(--border);
            padding: 16px;
            text-align: center;
            transition: transform 0.1s, border-color 0.15s, box-shadow 0.15s;
        }

        .letra-card:hover {
            border-color: var(--blue-main);
            box-shadow: 0 4px 0 var(--blue-shadow);
        }

        .letra-titulo {
            font-size: 34px;
            font-weight: 900;
            color: var(--card-brown);
            margin-bottom: 10px;
        }

        .imagem-wrapper {
            position: relative;
            width: 100%;
            aspect-ratio: 4 / 5;
            background: #f5f5f5;
            border-radius: 12px;
            overflow: hidden;
            cursor: zoom-in;
        }

        .imagem-wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            transition: transform 0.2s;
        }

        .imagem-wrapper:hover img {
            transform: scale(1.05);
        }

        .imagem-vazia {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 700;
            text-align: center;
            padding: 10px;
        }

        /* ===== LIGHTBOX (imagem ampliada) ===== */
        .lightbox {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.75);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 999;
            padding: 30px;
        }

        .lightbox.aberto {
            display: flex;
        }

        .lightbox-conteudo {
            background: var(--card-white);
            border-radius: 20px;
            padding: 20px;
            max-width: 420px;
            width: 100%;
            text-align: center;
            position: relative;
        }

        .lightbox-conteudo img {
            width: 100%;
            border-radius: 14px;
            display: block;
            margin-top: 10px;
        }

        .lightbox-letra {
            font-size: 30px;
            font-weight: 900;
            color: var(--card-brown);
        }

        .lightbox-fechar {
            position: absolute;
            top: -14px;
            right: -14px;
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: var(--card-white);
            border: 2px solid var(--border);
            font-size: 16px;
            font-weight: 800;
            color: var(--text-main);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 3px 0 var(--border);
        }

        /* ===== FOOTER / CRÉDITOS ===== */
        .app-footer {
            width: 100%;
            background: var(--card-white);
            border-top: 2px solid var(--border);
            margin-top: 50px;
            padding: 30px 20px;
        }

        .footer-content {
            max-width: 1100px;
            margin: 0 auto;
            text-align: center;
        }

        .footer-content h3 {
            font-size: 16px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--text-muted);
            margin-bottom: 14px;
        }

        .creditos-lista {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
            margin-bottom: 14px;
        }

        .credito-item {
            padding: 8px 16px;
            border-radius: 20px;
            background: #f5f5f5;
            color: var(--text-main);
            font-weight: 700;
            font-size: 14px;
            text-decoration: none;
            border: 2px solid var(--border);
            transition: background 0.15s;
        }

        .credito-item:hover {
            background: #ddf4ff;
            border-color: var(--blue-main);
            color: var(--blue-shadow);
        }

        .footer-note {
            font-size: 13px;
            color: var(--text-muted);
            font-weight: 600;
        }
    </style>
</head>

<body>

    <!-- Header -->
    <header class="app-header">
        <a href="trilha.php" class="logo">EntreGestos</a>
        <h1>Alfabeto em Libras</h1>
        <a href="trilha.php" class="back-link">← Voltar</a>
    </header>

    <!-- Main -->
    <main class="main-content">

        <div class="page-intro">
            <h2>Aprenda o alfabeto</h2>
            <p>Clique em cada letra para ver a imagem do sinal ampliada.</p>
        </div>

        <div class="alfabeto-grid">
            <?php foreach ($letras as $item): ?>
                <div class="letra-card">
                    <div class="letra-titulo"><?= htmlspecialchars($item->getLetra()) ?></div>

                    <?php if ($item->getImagemUrl() && $item->getImagemUrl() !== 'SEU_LINK_AQUI'): ?>
                        <div class="imagem-wrapper"
                             onclick="abrirImagem('<?= htmlspecialchars(addslashes($item->getImagemUrl())) ?>', '<?= htmlspecialchars(addslashes($item->getLetra())) ?>')">
                            <img src="<?= htmlspecialchars($item->getImagemUrl()) ?>"
                                 alt="Sinal da letra <?= htmlspecialchars($item->getLetra()) ?>"
                                 loading="lazy">
                        </div>
                    <?php else: ?>
                        <div class="imagem-wrapper" style="cursor: default;">
                            <div class="imagem-vazia">Sem imagem cadastrada</div>
                        </div>
                    <?php endif; ?>

                </div>
            <?php endforeach; ?>

            <?php if (empty($letras)): ?>
                <p style="grid-column: 1 / -1; text-align:center; color: var(--text-muted);">
                    Nenhuma letra cadastrada ainda. Rode o script SQL do alfabeto e cadastre os links das imagens.
                </p>
            <?php endif; ?>
        </div>

    </main>

    <!-- Footer / Créditos -->
    <footer class="app-footer">
        <div class="footer-content">
            <h3>Créditos das imagens</h3>
            <div class="creditos-lista">
                <?php foreach ($creditos as $c): ?>
                    <a href="<?= htmlspecialchars($c['url']) ?>" target="_blank" rel="noopener" class="credito-item">
                        <?= htmlspecialchars($c['nome']) ?>
                    </a>
                <?php endforeach; ?>
            </div>
            <p class="footer-note">
                Imagens com os sinais do alfabeto em Libras. Créditos aos canais/fontes listados acima.
                Todos os direitos pertencem aos respectivos autores. &middot; EntreGestos
            </p>
        </div>
    </footer>

    <!-- Lightbox -->
    <div class="lightbox" id="lightbox" onclick="fecharImagemSeForFundo(event)">
        <div class="lightbox-conteudo">
            <button class="lightbox-fechar" onclick="fecharImagem()">✖</button>
            <div class="lightbox-letra" id="lightboxLetra"></div>
            <img id="lightboxImg" src="" alt="">
        </div>
    </div>

    <script>
        function abrirImagem(url, letra) {
            document.getElementById('lightboxImg').src = url;
            document.getElementById('lightboxLetra').innerText = letra;
            document.getElementById('lightbox').classList.add('aberto');
        }

        function fecharImagem() {
            document.getElementById('lightbox').classList.remove('aberto');
        }

        function fecharImagemSeForFundo(event) {
            if (event.target.id === 'lightbox') {
                fecharImagem();
            }
        }

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') fecharImagem();
        });
    </script>

</body>

</html>
