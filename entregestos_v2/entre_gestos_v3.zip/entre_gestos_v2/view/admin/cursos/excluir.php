<?php
require_once(__DIR__ . "/../../../controller/CursoController.php");
$controller = new CursoController();
$controller->excluir();
