<?php
require_once(__DIR__ . "/../../../controller/LicaoController.php");
$controller = new LicaoController();
$controller->excluir();
