<?php

/**
 * Includes o layout do header da sidebar do admin.
 * $activePage deve ser definida antes de incluir este arquivo.
 * Ex: $activePage = 'usuarios';
 */

require_once __DIR__ . "/../../../util/config.php";
require_once __DIR__ . "/../../../controller/AuthController.php";

$auth = new AuthController();
$auth->exigirLogin();
$user = $auth->getUsuarioLogado();
if ($user['perfil'] !== 'administrador') {
    die("Acesso negado! Exclusivo para administradores.");
}

$paginas = [
    'dashboard'  => ['label' => 'Dashboard',   'icon' => '🏠', 'url' => BASE_URL . '/view/admin/dashboard.php',            'color' => '#1cb0f6'],
    'usuarios'   => ['label' => 'Usuários',    'icon' => '👤', 'url' => BASE_URL . '/view/admin/usuarios/listar.php',      'color' => '#ce82ff'],
    'cursos'     => ['label' => 'Cursos',      'icon' => '📚', 'url' => BASE_URL . '/view/admin/cursos/listar.php',        'color' => '#1cb0f6'],
    'secoes'     => ['label' => 'Seções',      'icon' => '📂', 'url' => BASE_URL . '/view/admin/secoes/listar.php',        'color' => '#ff9600'],
    'licoes'     => ['label' => 'Lições',      'icon' => '🎯', 'url' => BASE_URL . '/view/admin/licoes/listar.php',        'color' => '#58cc02'],
    'atividades' => ['label' => 'Atividades',  'icon' => '✏️', 'url' => BASE_URL . '/view/admin/atividades/listar.php',   'color' => '#ce82ff'],
];
$activePage = $activePage ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'Admin') ?> - EntreGestos</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #f0f4f8;
            --sidebar-bg: #ffffff;
            --card-bg: #ffffff;
            --text-main: #3c3c3c;
            --text-muted: #afafaf;
            --border: #e5e5e5;
            --green-main: #58cc02;
            --green-shadow: #58a700;
            --blue-main: #1cb0f6;
            --blue-shadow: #1899d6;
            --orange-main: #ff9600;
            --orange-shadow: #cc7800;
            --purple-main: #ce82ff;
            --purple-shadow: #a568cc;
            --red-main: #ff4b4b;
            --red-shadow: #ea2b2b;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Nunito', sans-serif;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: var(--sidebar-bg);
            border-right: 2px solid var(--border);
            padding: 25px 15px;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            z-index: 100;
        }

        .sidebar-logo {
            font-size: 22px;
            font-weight: 900;
            color: var(--blue-main);
            text-align: center;
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }

        .sidebar-badge {
            text-align: center;
            font-size: 12px;
            font-weight: 700;
            color: var(--text-muted);
            letter-spacing: 1px;
            margin-bottom: 35px;
        }

        .sidebar-divider {
            height: 2px;
            background: var(--border);
            border-radius: 2px;
            margin: 10px 0;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 13px 15px;
            margin-bottom: 6px;
            color: var(--text-muted);
            font-weight: 700;
            font-size: 16px;
            text-decoration: none;
            border-radius: 14px;
            transition: all 0.15s;
            border: 2px solid transparent;
        }

        .nav-link:hover {
            background-color: #f7f7f7;
            color: var(--text-main);
        }

        .nav-link.active {
            color: var(--blue-main);
            background-color: #ddf4ff;
            border-color: #b0e4ff;
        }

        .nav-icon {
            font-size: 20px;
            margin-right: 12px;
            width: 24px;
            text-align: center;
        }

        .nav-link-bottom {
            margin-top: auto;
        }

        .back-link {
            display: flex;
            align-items: center;
            padding: 13px 15px;
            color: var(--green-main);
            font-weight: 800;
            font-size: 15px;
            text-decoration: none;
            border-radius: 14px;
            border: 2px solid var(--green-main);
            background: #f0fff0;
            transition: all 0.15s;
        }

        .back-link:hover {
            background: #d7ffb8;
        }

        /* ===== MAIN ===== */
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 40px 50px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 30px;
            font-weight: 900;
        }

        /* Botão Primário */
        .btn {
            display: inline-block;
            padding: 12px 22px;
            border-radius: 14px;
            font-weight: 800;
            font-size: 16px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: transform 0.1s;
        }

        .btn:active {
            transform: translateY(3px);
        }

        .btn-primary {
            background: var(--green-main);
            color: white;
            box-shadow: 0 4px 0 var(--green-shadow);
        }

        .btn-primary:hover {
            filter: brightness(1.05);
        }

        .btn-warning {
            background: var(--orange-main);
            color: white;
            box-shadow: 0 4px 0 var(--orange-shadow);
        }

        .btn-danger {
            background: var(--red-main);
            color: white;
            box-shadow: 0 4px 0 var(--red-shadow);
        }

        .btn-secondary {
            background: var(--text-muted);
            color: white;
            box-shadow: 0 4px 0 #888;
        }

        .btn-sm {
            padding: 8px 14px;
            font-size: 14px;
            border-radius: 10px;
        }

        /* ===== TABLE ===== */
        .table-card {
            background: var(--card-bg);
            border-radius: 20px;
            border: 2px solid var(--border);
            overflow: hidden;
            box-shadow: 0 4px 0 var(--border);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead tr {
            background: var(--bg-color);
        }

        th {
            padding: 14px 20px;
            text-align: left;
            font-size: 13px;
            font-weight: 800;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 16px 20px;
            font-size: 16px;
            font-weight: 600;
            border-top: 2px solid var(--bg-color);
            vertical-align: middle;
        }

        tbody tr:hover {
            background: #fafafa;
        }

        td:last-child,
        th:last-child {
            text-align: right;
        }

        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 800;
        }

        .badge-green {
            background: #d7ffb8;
            color: var(--green-shadow);
        }

        .badge-red {
            background: #ffdfe0;
            color: var(--red-shadow);
        }

        .badge-blue {
            background: #ddf4ff;
            color: var(--blue-shadow);
        }

        .badge-purple {
            background: #faedff;
            color: var(--purple-shadow);
        }

        .badge-orange {
            background: #fff4e5;
            color: var(--orange-shadow);
        }

        /* ===== FORM ===== */
        .form-card {
            background: var(--card-bg);
            border-radius: 20px;
            border: 2px solid var(--border);
            padding: 35px;
            max-width: 600px;
            box-shadow: 0 4px 0 var(--border);
        }

        .form-group {
            margin-bottom: 22px;
        }

        .form-group label {
            display: block;
            font-weight: 800;
            font-size: 14px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }

        .form-control {
            width: 100%;
            padding: 13px 15px;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            font-family: 'Nunito', sans-serif;
            transition: border-color 0.15s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--blue-main);
            background: #f9feff;
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .form-check input {
            width: 20px;
            height: 20px;
            accent-color: var(--green-main);
            cursor: pointer;
        }

        .form-check span {
            font-weight: 700;
            font-size: 16px;
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 30px;
        }

        /* ===== DASHBOARD ===== */
        .dash-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .dash-card {
            background: white;
            border: 2px solid var(--border);
            border-radius: 20px;
            padding: 25px;
            text-decoration: none;
            color: var(--text-main);
            transition: transform 0.1s;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .dash-card:active {
            transform: translateY(4px);
        }

        .dash-card .card-icon {
            width: 64px;
            height: 64px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            flex-shrink: 0;
        }

        .dash-card .card-info h3 {
            font-size: 22px;
            font-weight: 900;
        }

        .dash-card .card-info p {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .dash-card.usuarios {
            border-color: var(--purple-main);
            box-shadow: 0 6px 0 var(--purple-shadow);
        }

        .dash-card.usuarios:hover {
            background: #faedff;
        }

        .dash-card.usuarios .card-icon {
            background: #faedff;
        }

        .dash-card.cursos {
            border-color: var(--blue-main);
            box-shadow: 0 6px 0 var(--blue-shadow);
        }

        .dash-card.cursos:hover {
            background: #ddf4ff;
        }

        .dash-card.cursos .card-icon {
            background: #ddf4ff;
        }

        .dash-card.secoes {
            border-color: var(--orange-main);
            box-shadow: 0 6px 0 var(--orange-shadow);
        }

        .dash-card.secoes:hover {
            background: #fff4e5;
        }

        .dash-card.secoes .card-icon {
            background: #fff4e5;
        }

        .dash-card.licoes {
            border-color: var(--green-main);
            box-shadow: 0 6px 0 var(--green-shadow);
        }

        .dash-card.licoes:hover {
            background: #d7ffb8;
        }

        .dash-card.licoes .card-icon {
            background: #d7ffb8;
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <div class="sidebar-logo">EntreGestos</div>
        <div class="sidebar-badge">PAINEL ADMIN</div>
        <div class="sidebar-divider"></div>

        <?php foreach ($paginas as $key => $pg): ?>
            <a href="<?= $pg['url'] ?>" class="nav-link <?= $activePage === $key ? 'active' : '' ?>">
                <span class="nav-icon"><?= $pg['icon'] ?></span>
                <?= $pg['label'] ?>
            </a>
        <?php endforeach; ?>

        <div class="nav-link-bottom">
            <div class="sidebar-divider"></div>
            <a href="<?= BASE_URL ?>/view/app/trilha.php" class="back-link">
                <span class="nav-icon">🎮</span> Ver App
            </a>
        </div>
    </div>

    <div class="main-content">