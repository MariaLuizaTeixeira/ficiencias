<?php
require_once(__DIR__ . "/../../../controller/SecaoController.php");
$controller = new SecaoController();
$controller->excluir();
