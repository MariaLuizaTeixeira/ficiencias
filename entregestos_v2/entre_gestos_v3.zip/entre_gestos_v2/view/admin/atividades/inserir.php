<?php
$pageTitle  = 'Nova Atividade';
$activePage = 'atividades';
require_once(__DIR__ . "/../../../controller/AtividadeController.php");
$controller = new AtividadeController();
if ($_SERVER['REQUEST_METHOD'] === 'POST') { $controller->salvar(); }
$licoes = $controller->listarLicoes();
$erro   = $_SESSION['erro_atividade'] ?? '';
unset($_SESSION['erro_atividade']);
require_once(__DIR__ . "/../componentes/admin_header.php");
?>

<style>
/* ── Wizard de atividades ───────────────────────────────── */
.wizard-steps {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0;
    margin-bottom: 28px;
}
.wizard-step {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
    font-weight: 700;
    color: var(--text-muted);
}
.wizard-step .bolinha {
    width: 30px; height: 30px;
    border-radius: 50%;
    border: 2px solid var(--border);
    display: flex; align-items: center; justify-content: center;
    font-size: 13px; font-weight: 800;
    background: white;
    transition: all .2s;
}
.wizard-step.ativo  { color: var(--text-main); }
.wizard-step.ativo .bolinha  { background: var(--blue-main); border-color: var(--blue-main); color: white; }
.wizard-step.concluido .bolinha { background: var(--green-main); border-color: var(--green-main); color: white; }
.wizard-step.concluido { color: var(--green-main); }
.wizard-linha { width: 50px; height: 2px; background: var(--border); margin: 0 4px; }

/* ── Telas do wizard ──────────────────────────────────── */
.wizard-section { display: none; }
.wizard-section.ativa { display: block; }

/* ── Cartões de tipo (step 1) ─────────────────────────── */
.tipos-grid {
    display: flex;
    gap: 18px;
    justify-content: center;
    flex-wrap: wrap;
    margin-top: 20px;
}
.tipo-card {
    background: white;
    border: 2px solid var(--border);
    border-radius: 18px;
    width: 160px; min-height: 130px;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    gap: 10px;
    padding: 20px 10px;
    cursor: pointer;
    font-weight: 800; font-size: 15px;
    color: var(--text-main);
    text-align: center;
    transition: all .15s;
    box-shadow: 0 4px 0 var(--border);
}
.tipo-card .tipo-icon { font-size: 34px; }
.tipo-card:hover { transform: translateY(-3px); border-color: var(--blue-main); box-shadow: 0 6px 0 var(--blue-shadow); }
.tipo-card.selecionado { border-color: var(--green-main); background: #f0fff0; box-shadow: 0 4px 0 var(--green-shadow); }

/* ── Tags de resumo ───────────────────────────────────── */
.resumo-tags {
    display: flex; flex-wrap: wrap; gap: 8px;
    margin-bottom: 22px;
}
.resumo-tag {
    display: inline-flex; align-items: center; gap: 8px;
    background: white; border: 1.5px solid var(--border);
    border-radius: 999px; padding: 5px 8px 5px 14px;
    font-size: 13px; font-weight: 700; color: var(--text-main);
}
.resumo-tag button {
    border: none; background: var(--text-muted); color: white;
    border-radius: 999px; padding: 2px 10px;
    font-size: 12px; cursor: pointer; font-family: inherit; font-weight: 700;
}
.resumo-tag button:hover { background: var(--text-main); }

/* ── Pares associativos ─────────────────────────────── */
.pares-grid { display: flex; flex-direction: column; gap: 10px; margin-bottom: 16px; }
.par-linha { display: grid; grid-template-columns: 1fr auto 1fr; gap: 10px; align-items: center; }
.par-seta { color: var(--text-muted); font-size: 20px; text-align: center; }

/* ── Seção do form específico ──────────────────────── */
.bloco-tipo { display: none; }

/* ── Erro ─────────────────────────────────────────── */
.alerta-erro {
    background: #ffdfe0; border: 2px solid #ea2b2b; border-radius: 14px;
    padding: 14px 20px; margin-bottom: 22px;
    font-weight: 700; color: #ea2b2b;
}
</style>

<div class="page-header">
    <h1>✏️ Nova Atividade</h1>
    <a href="listar.php" class="btn btn-secondary">← Voltar</a>
</div>

<?php if ($erro): ?>
<div class="alerta-erro">⚠ <?= htmlspecialchars($erro) ?></div>
<?php endif; ?>

<!-- Indicador de passos -->
<div id="indicadorPassos" class="wizard-steps">
    <div class="wizard-step ativo" data-passo="1">
        <div class="bolinha">1</div> Tipo
    </div>
    <div class="wizard-linha"></div>
    <div class="wizard-step" data-passo="2">
        <div class="bolinha">2</div> Formulário
    </div>
</div>

<!-- ─── Tela 1: Escolha do tipo ─────────────────────────────────────── -->
<div id="tela-tipo" class="form-card wizard-section ativa">
    <p style="text-align:center;color:var(--text-muted);font-weight:700;font-size:15px;margin-bottom:4px;">
        Qual é o tipo de atividade?
    </p>
    <div class="tipos-grid">
        <button type="button" class="tipo-card" data-valor="options">
            <span class="tipo-icon">☑</span>
            Múltipla Escolha
        </button>
        <button type="button" class="tipo-card" data-valor="association">
            <span class="tipo-icon">🔗</span>
            Associativa
        </button>
        <button type="button" class="tipo-card" data-valor="open">
            <span class="tipo-icon">✍</span>
            Escrita
        </button>
    </div>
</div>

<!-- ─── Tela 2: Formulário ──────────────────────────────────────────── -->
<div id="tela-form" class="form-card wizard-section">

    <div id="resumoTela2" class="resumo-tags"></div>

    <form method="POST" id="formAtividade">
        <input type="hidden" name="tipo_interacao" id="input_tipo_interacao">

        <!-- Lição -->
        <div class="form-group">
            <label>Lição</label>
            <select name="licao_id" id="licao_id" class="form-control" required>
                <option value="">Selecione a lição...</option>
                <?php foreach ($licoes as $l): ?>
                <option value="<?= $l->getId() ?>">
                    <?= htmlspecialchars(($l->curso_nome ?? '') . ' › ' . ($l->secao_titulo ?? '') . ' › ' . $l->getTitulo()) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Enunciado -->
        <div class="form-group">
            <label>Enunciado</label>
            <textarea name="enunciado" class="form-control" required rows="3"
                      placeholder="Escreva aqui a pergunta ou instrução da atividade..."></textarea>
        </div>

        <!-- ─── Bloco: Múltipla Escolha ──────────────────────────── -->
        <div id="bloco-options" class="bloco-tipo">
            <div style="border-top:2px solid var(--border);padding-top:20px;margin-bottom:16px;">
                <strong style="font-size:15px;">Opções de Resposta</strong>
            </div>
            <div id="opcoesContainer">
                <?php for ($i = 1; $i <= 4; $i++): ?>
                <div class="form-group">
                    <label>Opção <?= $i ?></label>
                    <input type="text" name="opcao_<?= $i ?>_texto" class="form-control"
                           placeholder="Texto da opção <?= $i ?>...">
                </div>
                <?php endfor; ?>
            </div>
            <div class="form-group">
                <label>Qual é a Resposta Correta?</label>
                <select name="opcao_correta" id="opcao_correta" class="form-control">
                    <option value="">— Selecione —</option>
                    <option value="1">Opção 1</option>
                    <option value="2">Opção 2</option>
                    <option value="3">Opção 3</option>
                    <option value="4">Opção 4</option>
                </select>
            </div>
        </div>

        <!-- ─── Bloco: Associativa ───────────────────────────────── -->
        <div id="bloco-association" class="bloco-tipo">
            <div style="border-top:2px solid var(--border);padding-top:20px;margin-bottom:8px;">
                <strong style="font-size:15px;">Pares Associativos</strong>
            </div>
            <p style="color:var(--text-muted);font-size:14px;font-weight:600;margin-bottom:16px;">
                Relacione cada item da esquerda com o correspondente da direita.
            </p>
            <div class="pares-grid" id="paresContainer"></div>
            <input type="hidden" name="qtd_pares" id="qtd_pares" value="4">
            <button type="button" id="btnAddPar" class="btn btn-secondary btn-sm" style="margin-bottom:20px;">
                + Adicionar par
            </button>
        </div>

        <!-- ─── Bloco: Escrita (Aberta) ─────────────────────────── -->
        <div id="bloco-open" class="bloco-tipo">
            <div style="border-top:2px solid var(--border);padding-top:20px;margin-bottom:16px;">
                <strong style="font-size:15px;">Resposta Esperada</strong>
            </div>
            <div class="form-group">
                <label>Resposta Correta</label>
                <input type="text" name="resposta_correta" class="form-control"
                       placeholder="A resposta que o aluno deve digitar...">
            </div>
        </div>

        <div class="form-actions">
            <button type="button" id="btnVoltar" class="btn btn-secondary">← Voltar</button>
            <button type="submit" class="btn btn-primary">Salvar Atividade ✓</button>
        </div>
    </form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {

    const telaTipo = document.getElementById("tela-tipo");
    const telaForm = document.getElementById("tela-form");
    const inputTipoInteracao = document.getElementById("input_tipo_interacao");
    const resumoTela2 = document.getElementById("resumoTela2");
    const indicador   = document.getElementById("indicadorPassos");
    const paresContainer = document.getElementById("paresContainer");
    const qtdParesInput  = document.getElementById("qtd_pares");
    const btnAddPar      = document.getElementById("btnAddPar");

    const rotulosInteracao = {
        options:     "☑ Múltipla Escolha",
        association: "🔗 Associativa",
        open:        "✍ Escrita"
    };

    let tipoSelecionado = null;
    let qtdPares = 0;

    // ── Navegação entre telas ──────────────────────────────────────────
    function mostrarTela(id) {
        [telaTipo, telaForm].forEach(t => t.classList.remove("ativa"));
        document.getElementById(id).classList.add("ativa");

        const mapa = { "tela-tipo": 1, "tela-form": 2 };
        const atual = mapa[id];
        indicador.querySelectorAll(".wizard-step").forEach(el => {
            const n = parseInt(el.dataset.passo, 10);
            el.classList.remove("ativo", "concluido");
            if (n === atual) el.classList.add("ativo");
            else if (n < atual) el.classList.add("concluido");
        });
    }

    // ── Seleção do tipo (Tela 1 → Tela 2) ─────────────────────────────
    telaTipo.querySelectorAll(".tipo-card").forEach(btn => {
        btn.addEventListener("click", function () {
            tipoSelecionado = this.dataset.valor;

            // Atualiza hidden input
            inputTipoInteracao.value = tipoSelecionado;

            // Resumo tag
            resumoTela2.innerHTML = "";
            const tag = document.createElement("span");
            tag.className = "resumo-tag";
            tag.innerHTML = rotulosInteracao[tipoSelecionado] + " ";
            const trocar = document.createElement("button");
            trocar.type = "button";
            trocar.textContent = "trocar";
            trocar.addEventListener("click", () => mostrarTela("tela-tipo"));
            tag.appendChild(trocar);
            resumoTela2.appendChild(tag);

            // Mostra o bloco correto
            document.querySelectorAll(".bloco-tipo").forEach(b => b.style.display = "none");
            const bloco = document.getElementById("bloco-" + tipoSelecionado);
            if (bloco) bloco.style.display = "block";

            // Inicializa pares se associativa
            if (tipoSelecionado === "association" && qtdPares === 0) {
                for (let i = 0; i < 4; i++) adicionarPar();
            }

            mostrarTela("tela-form");
        });
    });

    // ── Botão Voltar (Tela 2 → Tela 1) ────────────────────────────────
    document.getElementById("btnVoltar").addEventListener("click", () => {
        mostrarTela("tela-tipo");
    });

    // ── Pares associativos ─────────────────────────────────────────────
    function adicionarPar() {
        qtdPares++;
        qtdParesInput.value = qtdPares;

        const div = document.createElement("div");
        div.className = "par-linha";
        div.innerHTML = `
            <input type="text" name="par_${qtdPares}_esquerdo" class="form-control"
                   placeholder="Alternativa ${qtdPares}…">
            <div class="par-seta">→</div>
            <input type="text" name="par_${qtdPares}_direito" class="form-control"
                   placeholder="Resposta ${qtdPares}…">
        `;
        paresContainer.appendChild(div);
    }

    btnAddPar.addEventListener("click", adicionarPar);

    // Inicia na tela 1
    mostrarTela("tela-tipo");
});
</script>

<?php require_once(__DIR__ . "/../componentes/admin_footer.php"); ?>
