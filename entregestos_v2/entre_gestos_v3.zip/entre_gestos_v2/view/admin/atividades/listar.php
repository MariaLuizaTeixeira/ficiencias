<?php
$pageTitle  = 'Atividades';
$activePage = 'atividades';
require_once(__DIR__ . "/../../../controller/AtividadeController.php");
$controller  = new AtividadeController();
$atividades  = $controller->listar();
$sucesso     = $_SESSION['sucesso_atividade'] ?? '';
unset($_SESSION['sucesso_atividade']);
require_once(__DIR__ . "/../componentes/admin_header.php");
?>

<div class="page-header">
    <h1>✏️ Atividades</h1>
    <a href="inserir.php" class="btn btn-primary">+ Nova Atividade</a>
</div>

<?php if ($sucesso): ?>
<div style="background:#d7ffb8;border:2px solid #58a700;border-radius:14px;padding:14px 20px;margin-bottom:24px;font-weight:700;color:#58a700;">
    ✓ <?= htmlspecialchars($sucesso) ?>
</div>
<?php endif; ?>

<div class="table-card">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Curso / Seção / Lição</th>
                <th>Enunciado</th>
                <th>Tipo</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($atividades as $a): ?>
            <tr>
                <td style="color:var(--text-muted);"><?= $a['id'] ?></td>
                <td>
                    <span class="badge badge-blue"><?= htmlspecialchars($a['curso_nome']) ?></span><br>
                    <small style="color:var(--text-muted);font-weight:700;">
                        <?= htmlspecialchars($a['secao_titulo']) ?> &rsaquo; <?= htmlspecialchars($a['licao_titulo']) ?>
                    </small>
                </td>
                <td><strong><?= htmlspecialchars(mb_strimwidth($a['enunciado'], 0, 70, '…')) ?></strong></td>
                <td>
                    <?php
                    $badges = [
                        'multipla_escolha' => ['badge-green',  '☑ Múltipla Escolha'],
                        'associacao'       => ['badge-purple', '🔗 Associativa'],
                        'aberta'           => ['badge-orange', '✍ Escrita'],
                    ];
                    [$cls, $label] = $badges[$a['tipo']] ?? ['badge-blue', $a['tipo']];
                    ?>
                    <span class="badge <?= $cls ?>"><?= $label ?></span>
                </td>
                <td>
                    <a href="editar.php?id=<?= $a['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                    <a href="excluir.php?id=<?= $a['id'] ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Excluir esta atividade e todas as suas opções?')">Excluir</a>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($atividades)): ?>
            <tr>
                <td colspan="5" style="text-align:center;color:var(--text-muted);padding:40px;">
                    Nenhuma atividade cadastrada.
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once(__DIR__ . "/../componentes/admin_footer.php"); ?>
