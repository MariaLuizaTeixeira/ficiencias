<?php
require_once(__DIR__ . "/../../../controller/AtividadeController.php");
$controller = new AtividadeController();
$controller->excluir();
