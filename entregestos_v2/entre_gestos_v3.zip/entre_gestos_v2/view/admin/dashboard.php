<?php
$pageTitle  = 'Dashboard';
$activePage = 'dashboard';

require_once(__DIR__ . "/../../controller/UsuarioController.php");
require_once(__DIR__ . "/../../controller/CursoController.php");
require_once(__DIR__ . "/../../controller/SecaoController.php");
require_once(__DIR__ . "/../../controller/LicaoController.php");

$totalUsuarios = count((new UsuarioController())->listar());
$totalCursos   = count((new CursoController())->listar());
$totalSecoes   = count((new SecaoController())->listar());
$totalLicoes   = count((new LicaoController())->listar());

require_once(__DIR__ . "/componentes/admin_header.php");
?>

<div class="page-header">
    <h1>Dashboard</h1>
</div>

<div class="dash-grid">
    <a href="<?= BASE_URL ?>/view/admin/usuarios/listar.php" class="dash-card usuarios">
        <div class="card-icon">👤</div>
        <div class="card-info">
            <h3><?= $totalUsuarios ?></h3>
            <p>Usuários cadastrados</p>
        </div>
    </a>
    <a href="<?= BASE_URL ?>/view/admin/cursos/listar.php" class="dash-card cursos">
        <div class="card-icon">📚</div>
        <div class="card-info">
            <h3><?= $totalCursos ?></h3>
            <p>Cursos ativos</p>
        </div>
    </a>
    <a href="<?= BASE_URL ?>/view/admin/secoes/listar.php" class="dash-card secoes">
        <div class="card-icon">📂</div>
        <div class="card-info">
            <h3><?= $totalSecoes ?></h3>
            <p>Seções criadas</p>
        </div>
    </a>
    <a href="<?= BASE_URL ?>/view/admin/licoes/listar.php" class="dash-card licoes">
        <div class="card-icon">🎯</div>
        <div class="card-info">
            <h3><?= $totalLicoes ?></h3>
            <p>Lições disponíveis</p>
        </div>
    </a>
</div>

<?php require_once(__DIR__ . "/componentes/admin_footer.php"); ?>
