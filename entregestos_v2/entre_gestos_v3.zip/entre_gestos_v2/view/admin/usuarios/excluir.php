<?php
require_once(__DIR__ . "/../../../controller/UsuarioController.php");

$controller = new UsuarioController();
$controller->excluir();
