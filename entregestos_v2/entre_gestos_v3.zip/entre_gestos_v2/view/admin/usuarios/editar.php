<?php
$pageTitle  = 'Editar Usuário';
$activePage = 'usuarios';
require_once(__DIR__ . "/../../../controller/UsuarioController.php");
$controller = new UsuarioController();
if($_SERVER['REQUEST_METHOD'] === 'POST') { $controller->salvar(); }
else if(isset($_GET['id'])) { $usuario = $controller->buscarPorId($_GET['id']); if(!$usuario) die("Não encontrado."); }
else { header("Location: listar.php"); exit; }
require_once(__DIR__ . "/../componentes/admin_header.php");
?>

<div class="page-header">
    <h1>👤 Editar Usuário</h1>
    <a href="listar.php" class="btn btn-secondary">← Voltar</a>
</div>

<div class="form-card">
    <form method="POST">
        <input type="hidden" name="id" value="<?= $usuario->getId() ?>">
        <div class="form-group">
            <label>Nome Completo</label>
            <input type="text" name="nome_completo" class="form-control" value="<?= htmlspecialchars($usuario->getNomeCompleto()) ?>" required>
        </div>
        <div class="form-group">
            <label>E-mail</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($usuario->getEmail()) ?>" required>
        </div>
        <div class="form-group">
            <label>Perfil</label>
            <select name="perfil" class="form-control" required>
                <option value="aluno"          <?= $usuario->getPerfil() === 'aluno'          ? 'selected' : '' ?>>Aluno</option>
                <option value="administrador"  <?= $usuario->getPerfil() === 'administrador'  ? 'selected' : '' ?>>Administrador</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-check">
                <input type="checkbox" name="email_verificado" value="1" <?= $usuario->getEmailVerificado() ? 'checked' : '' ?>>
                <span>E-mail verificado</span>
            </label>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-warning">Atualizar</button>
            <a href="listar.php" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>
</div>

<?php require_once(__DIR__ . "/../componentes/admin_footer.php"); ?>
