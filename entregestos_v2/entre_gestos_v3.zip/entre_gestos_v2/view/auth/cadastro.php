<?php
require_once(__DIR__ . "/../../controller/AuthController.php");

$authController = new AuthController();

if ($authController->estaLogado()) {
    header("Location: ../app/trilha.php");
    exit;
}

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';

    if ($senha !== $confirmar_senha) {
        $erro = 'Uai, as senhas não tão batendo! Dá uma conferida aí, sô.';
    } else {
        $resultado = $authController->cadastrar($nome, $email, $senha);

        if (empty($resultado)) {
            header("Location: ../app/trilha.php");
            exit;
        } else {
            $erro = $resultado;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - EntreGestos</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #fdfaf6;
            --text-main: #8c7355;
            --text-muted: #b59b7b;
            --green-main: #58cc02;
            --green-shadow: #58a700;
            --card-white: #ffffff;
            --input-bg: #f5f0eb;
            --border: #e5e5e5;
            --secondary-btn: #fffaf5;
            --secondary-border: #d8c3a5;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Nunito', sans-serif;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
            align-items: center;
            justify-content: center;
        }

        .split-layout {
            display: flex;
            width: 100%;
            max-width: 1000px;
            align-items: center;
            justify-content: center;
            padding: 20px;
            gap: 60px;
        }

        .left-side {
            flex: 1;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .mascote {
            font-size: 140px;
            line-height: 1;
            margin-bottom: 20px;
        }

        .left-side h1 {
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 15px;
            color: var(--text-main);
        }

        .left-side p {
            font-size: 16px;
            font-weight: 700;
            color: var(--text-muted);
        }

        .right-side {
            flex: 1;
            max-width: 450px;
            width: 100%;
        }

        .login-card {
            background: var(--card-white);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(140, 115, 85, 0.08);
            width: 100%;
            text-align: center;
        }

        .login-card h2 {
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 8px;
            color: var(--text-main);
        }

        .login-card>p {
            font-size: 14px;
            font-weight: 700;
            color: var(--text-muted);
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 800;
            color: var(--text-muted);
            margin-bottom: 8px;
            padding-left: 5px;
        }

        .input-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-icon {
            position: absolute;
            left: 15px;
            font-size: 16px;
            color: var(--text-muted);
            pointer-events: none;
        }

        .form-control {
            width: 100%;
            background: var(--input-bg);
            border: 2px solid transparent;
            border-radius: 16px;
            padding: 14px 20px 14px 45px;
            font-size: 15px;
            font-weight: 700;
            color: var(--text-main);
            outline: none;
            transition: all 0.2s;
        }

        .form-control:focus {
            border-color: var(--green-main);
            background: var(--card-white);
        }

        .form-control::placeholder {
            color: #c9b59e;
            font-weight: 600;
        }

        .btn-main {
            width: 100%;
            background-color: var(--green-main);
            color: white;
            border: none;
            border-radius: 16px;
            padding: 16px;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 4px 0 var(--green-shadow);
            transition: transform 0.1s;
            margin-top: 10px;
            margin-bottom: 15px;
        }

        .btn-main:active {
            transform: translateY(4px);
            box-shadow: 0 0 0 transparent;
        }

        .divider {
            height: 1px;
            background-color: var(--input-bg);
            margin: 25px 0;
        }

        .footer-link {
            font-size: 13px;
            font-weight: 700;
            color: var(--text-muted);
        }

        .footer-link a {
            color: #ff9b71;
            text-decoration: none;
        }

        .footer-link a:hover {
            text-decoration: underline;
        }

        .error-message {
            background-color: #ffdfe0;
            color: #ff4b4b;
            padding: 12px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 14px;
            margin-bottom: 20px;
            border: 2px solid #ffb3b8;
        }

        @media (max-width: 850px) {
            .split-layout {
                flex-direction: column;
                gap: 30px;
            }

            .mascote {
                font-size: 100px;
            }

            .left-side h1 {
                font-size: 26px;
            }
        }
    </style>
</head>

<body>

    <div class="split-layout">
        <!-- Esquerda: Capivara / Mensagem -->
        <div class="left-side">
            <div class="mascote">
                <img src="<?= BASE_URL ?>/view/assets/imagens/capivara.png" alt="Capivara">
            </div>
            <h1>Aprenda Libras com a Capivara!</h1>
            <p>Sua jornada de aprendizado começa aqui 🌱</p>
        </div>

        <!-- Direita: Card de Cadastro -->
        <div class="right-side">
            <div class="login-card">
                <h2>Criar sua conta</h2>
                <p>Venha fazer parte dessa comunidade</p>

                <?php if (!empty($erro)): ?>
                    <div class="error-message">
                        <?= htmlspecialchars($erro) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label>Nome Completo</label>
                        <div class="input-wrapper">
                            <span class="input-icon">👤</span>
                            <input type="text" name="nome" class="form-control" placeholder="Seu Nome" required autofocus>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <div class="input-wrapper">
                            <span class="input-icon">✉️</span>
                            <input type="email" name="email" class="form-control" placeholder="seu@email.com" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Senha</label>
                        <div class="input-wrapper">
                            <span class="input-icon">🔒</span>
                            <input type="password" name="senha" class="form-control" placeholder="••••••••" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Confirme a Senha</label>
                        <div class="input-wrapper">
                            <span class="input-icon">🔑</span>
                            <input type="password" name="confirmar_senha" class="form-control" placeholder="••••••••" required>
                        </div>
                    </div>

                    <button type="submit" class="btn-main">Cadastrar</button>
                </form>

                <div class="divider"></div>

                <div class="footer-link">
                    Já tem uma conta? <a href="login.php">Fazer Login</a>
                </div>
            </div>
        </div>
    </div>

</body>

</html>