<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Aluno.php");

class AlunoDAO
{

    private PDO $connection;

    public function __construct()
    {
        $this->connection = Connection::getConnection();
    }

    public function list()
    {
        $sql = "SELECT * FROM alunos";
        $stm = $this->connection->prepare($sql);
        $stm->execute();
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function insert(Aluno $aluno): Aluno
    {
        $sql = "INSERT INTO alunos (id_usuario, vidas, sequencia) VALUES (?, ?, ?)";
        $stm = $this->connection->prepare($sql);
        $stm->execute([$aluno->getIdUsuario(), $aluno->getVidas(), $aluno->getSequencia()]);
        $aluno->setId($this->connection->lastInsertId());

        return $aluno;
    }

    private function mapOne(array $alunoData): Aluno
    {
        $aluno = new Aluno();
        $aluno->setId($alunoData['id']);
        $aluno->setIdUsuario($alunoData['id_usuario']);
        $aluno->setVidas($alunoData['vidas']);
        $aluno->setSequencia($alunoData['sequencia']);

        return $aluno;
    }

    private function map(array $dados): array
    {
        $alunos = array();

        foreach ($dados as $d) {
            array_push($alunos, $this->mapOne($d));
        }

        return $alunos;
    }
}
