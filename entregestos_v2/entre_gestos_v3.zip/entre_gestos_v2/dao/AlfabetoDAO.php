<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Alfabeto.php");

class AlfabetoDAO
{

    // =========================================================
    // LISTAR
    // =========================================================
    public function list()
    {
        $sql = "SELECT * FROM alfabeto ORDER BY ordem";

        $conn = Connection::getConnection();

        $stm = $conn->prepare($sql);
        $stm->execute();

        $dados = $stm->fetchAll(PDO::FETCH_ASSOC);

        return $this->map($dados);
    }


    // =========================================================
    // MAP
    // =========================================================
    private function map(array $dados)
    {
        $letras = array();

        foreach ($dados as $d) {

            $letra = new Alfabeto();

            $letra->setId($d["id"]);
            $letra->setLetra($d["letra"]);
            $letra->setImagemUrl($d["imagem_url"]);
            $letra->setOrdem($d["ordem"]);

            array_push($letras, $letra);
        }

        return $letras;
    }
}
