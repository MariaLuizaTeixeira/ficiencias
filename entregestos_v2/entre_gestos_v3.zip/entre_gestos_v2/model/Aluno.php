<?php

require_once(__DIR__ . "/Curso.php");

class Aluno
{

    private int $id;
    private int $id_usuario;
    private int $vidas;
    private int $sequencia;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function getIdUsuario(): int
    {
        return $this->id_usuario;
    }

    public function setIdUsuario(int $id_usuario): void
    {
        $this->id_usuario = $id_usuario;
    }

    public function getVidas(): int
    {
        return $this->vidas;
    }

    public function setVidas(int $vidas): void
    {
        $this->vidas = $vidas;
    }

    public function getSequencia(): int
    {
        return $this->sequencia;
    }

    public function setSequencia(int $sequencia): void
    {
        $this->sequencia = $sequencia;
    }
}
