<?php

require_once(__DIR__ . "/../model/Aluno.php");

class AlunoService
{

    public function validar(Aluno $aluno) {}
}
