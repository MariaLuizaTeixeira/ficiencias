<?php

require_once(__DIR__ . "/../model/Usuario.php");
require_once(__DIR__ . "/../model/Aluno.php");
require_once(__DIR__ . "/../dao/UsuarioDAO.php");
require_once(__DIR__ . "/../dao/AlunoDAO.php");

class UsuarioService
{

    public function validar(Usuario $usuario) {}

    public function insert(Usuario $usuario)
    {
        $usuarioDAO = new UsuarioDAO();
        $usuario = $usuarioDAO->insert($usuario);

        $aluno = new Aluno();
        $aluno->setIdUsuario($usuario->getId());
        $aluno->setVidas(5);
        $aluno->setSequencia(0);

        $alunoDAO = new AlunoDAO();
        $alunoDAO->insert($aluno);

        return $usuario;
    }
}
