CREATE DATABASE IF NOT EXISTS entregestos;
USE entregestos;

-- ==========================================
-- REMOVER TABELAS EXISTENTES
-- ==========================================

DROP TABLE IF EXISTS respostas_multipla_escolha;
DROP TABLE IF EXISTS respostas_associacao;
DROP TABLE IF EXISTS respostas_abertas;
DROP TABLE IF EXISTS respostas;
DROP TABLE IF EXISTS progresso_questao;
DROP TABLE IF EXISTS progresso_licoes;
DROP TABLE IF EXISTS pares_associativos;
DROP TABLE IF EXISTS opcoes_questao;
DROP TABLE IF EXISTS itens_associativos;
DROP TABLE IF EXISTS questoes_multipla_escolha;
DROP TABLE IF EXISTS questoes_associativas;
DROP TABLE IF EXISTS questoes_abertas;
DROP TABLE IF EXISTS questoes;
DROP TABLE IF EXISTS licoes;
DROP TABLE IF EXISTS alfabeto;
DROP TABLE IF EXISTS alunos;
DROP TABLE IF EXISTS secoes;
DROP TABLE IF EXISTS usuarios;
DROP TABLE IF EXISTS tipos_questao;
DROP TABLE IF EXISTS cursos;


-- ==========================================
-- TABELAS
-- ==========================================

CREATE TABLE cursos (
    id bigint NOT NULL AUTO_INCREMENT,
    nome varchar(64) NOT NULL,
    descricao text,
    PRIMARY KEY (id)
);

CREATE TABLE tipos_questao (
    nome varchar(32) NOT NULL,
    PRIMARY KEY (nome)
);

CREATE TABLE usuarios (
    id bigint NOT NULL AUTO_INCREMENT,
    nome_completo varchar(64) NOT NULL,
    email varchar(64) NOT NULL,
    senha_hash varchar(512) NOT NULL,
    criado_em timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    email_verificado tinyint(1) NOT NULL DEFAULT 0,
    perfil varchar(16) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY (email)
);

CREATE TABLE secoes (
    id bigint NOT NULL AUTO_INCREMENT,
    curso_id bigint NOT NULL,
    titulo varchar(64) NOT NULL,
    ordem int NOT NULL,
    descricao text,
    PRIMARY KEY (id),
    FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE CASCADE
);

CREATE TABLE alunos (
    id bigint NOT NULL AUTO_INCREMENT,
    id_usuario bigint NOT NULL,
    vidas bigint NOT NULL,
    sequencia bigint NOT NULL,
    data_nascimento date DEFAULT NULL,
    apelido varchar(16) DEFAULT NULL,
    genero varchar(16) DEFAULT NULL,
    numero_telefone varchar(15) DEFAULT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE alfabeto (
    id bigint NOT NULL AUTO_INCREMENT,
    letra char(1) NOT NULL,
    imagem_url varchar(512) NOT NULL,
    ordem int NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY (letra)
);

CREATE TABLE licoes (
    id bigint NOT NULL AUTO_INCREMENT,
    secao_id bigint NOT NULL,
    titulo varchar(64) NOT NULL,
    ordem int NOT NULL,
    esta_bloqueada int NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    FOREIGN KEY (secao_id) REFERENCES secoes(id) ON DELETE CASCADE
);

CREATE TABLE questoes (
    id bigint NOT NULL AUTO_INCREMENT,
    enunciado text NOT NULL,
    tipo varchar(32) NOT NULL,
    licao_id bigint DEFAULT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (tipo) REFERENCES tipos_questao(nome),
    FOREIGN KEY (licao_id) REFERENCES licoes(id) ON DELETE CASCADE
);

CREATE TABLE questoes_abertas (
    id bigint NOT NULL,
    resposta_correta text NOT NULL,
    conteudo text NOT NULL,
    tipo_conteudo varchar(16) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id) REFERENCES questoes(id) ON DELETE CASCADE
);

CREATE TABLE questoes_associativas (
    id bigint NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id) REFERENCES questoes(id) ON DELETE CASCADE
);

CREATE TABLE questoes_multipla_escolha (
    id bigint NOT NULL,
    conteudo text NOT NULL,
    tipo_conteudo varchar(16) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id) REFERENCES questoes(id) ON DELETE CASCADE
);

CREATE TABLE itens_associativos (
    id bigint NOT NULL AUTO_INCREMENT,
    conteudo text NOT NULL,
    tipo_conteudo varchar(16) NOT NULL,
    coluna char(1) NOT NULL,
    questao_id bigint NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (questao_id)
        REFERENCES questoes_associativas(id)
        ON DELETE CASCADE
);

CREATE TABLE opcoes_questao (
    id bigint NOT NULL AUTO_INCREMENT,
    questao_id bigint NOT NULL,
    conteudo text NOT NULL,
    tipo_conteudo varchar(16) NOT NULL,
    esta_correta tinyint(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    FOREIGN KEY (questao_id)
        REFERENCES questoes_multipla_escolha(id)
        ON DELETE CASCADE
);

CREATE TABLE pares_associativos (
    id bigint NOT NULL AUTO_INCREMENT,
    item_esquerdo_id bigint NOT NULL,
    item_direito_id bigint NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY (item_esquerdo_id, item_direito_id),
    FOREIGN KEY (item_esquerdo_id)
        REFERENCES itens_associativos(id)
        ON DELETE CASCADE,
    FOREIGN KEY (item_direito_id)
        REFERENCES itens_associativos(id)
        ON DELETE CASCADE
);

CREATE TABLE progresso_licoes (
    id bigint NOT NULL AUTO_INCREMENT,
    aluno_id bigint NOT NULL,
    licao_id bigint NOT NULL,
    completada tinyint(1) NOT NULL DEFAULT 0,
    completado_em timestamp NULL DEFAULT NULL,
    acertou tinyint(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    FOREIGN KEY (licao_id)
        REFERENCES licoes(id)
        ON DELETE CASCADE
);

CREATE TABLE progresso_questao (
    aluno_id bigint NOT NULL,
    questao_id bigint NOT NULL,
    tentativas int NOT NULL DEFAULT 0,
    esta_correta tinyint(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (aluno_id, questao_id),
    FOREIGN KEY (questao_id)
        REFERENCES questoes(id)
        ON DELETE CASCADE
);

CREATE TABLE respostas (
    id bigint NOT NULL AUTO_INCREMENT,
    questao_id bigint NOT NULL,
    aluno_id bigint NOT NULL,
    criado_em timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    esta_correta tinyint(1) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (questao_id)
        REFERENCES questoes(id)
        ON DELETE CASCADE
);

CREATE TABLE respostas_abertas (
    id bigint NOT NULL,
    resposta_texto text NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES respostas(id)
        ON DELETE CASCADE
);

CREATE TABLE respostas_associacao (
    id bigint NOT NULL AUTO_INCREMENT,
    item_esquerdo_id bigint NOT NULL,
    item_direito_id bigint NOT NULL,
    resposta_id bigint NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (item_esquerdo_id)
        REFERENCES itens_associativos(id),
    FOREIGN KEY (item_direito_id)
        REFERENCES itens_associativos(id),
    FOREIGN KEY (resposta_id)
        REFERENCES respostas(id)
        ON DELETE CASCADE
);

CREATE TABLE respostas_multipla_escolha (
    id bigint NOT NULL,
    opcao_selecionada_id bigint NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (opcao_selecionada_id)
        REFERENCES opcoes_questao(id),
    FOREIGN KEY (id)
        REFERENCES respostas(id)
        ON DELETE CASCADE
);


-- ==========================================
-- DADOS
-- ==========================================

INSERT INTO cursos VALUES
(1, 'LIBRAS básico', 'Curso de LIBRAS para iniciantes do 0.');


INSERT INTO tipos_questao VALUES
('aberta'),
('associacao'),
('multipla_escolha');


INSERT INTO usuarios VALUES
(1, 'Aluno', 'aluno@entregestos.com',
 '$2y$12$EbGTg1FUQzB.VMGntOV2c.7I5EZevsWR8rm9zIXgctPQrddUOYqYu',
 '2026-08-16 13:04:22',
 '2026-08-28 16:49:42',
 1,
 'aluno'),

(2, 'Administrador', 'admin@entregestos.com',
 '$2y$12$nSr2kqdBawTea9N8aLaEtOt.J0yq913SPIm27MQ5lIN5nycjmC2rC',
 '2026-08-26 02:28:03',
 '2026-08-28 16:49:55',
 1,
 'administrador'),

(16, 'Brenda Melissa', 'brenda125@gmail.com',
 '$2y$12$G4hW29viMQFqCyb5cuqpPuYYZ91ui/wkhpkjbmok48wGjpyTP6iTm',
 '2026-09-04 12:29:05',
 '2026-09-04 12:29:05',
 1,
 'aluno');


INSERT INTO secoes VALUES
(1, 1, 'Introdução à LIBRAS', 1,
 'Aprenda o básico do alfabeto e saudações essenciais.'),

(2, 1, 'O Dia a Dia em LIBRAS', 2,
 'Vocabulário essencial para o dia a dia, como cores e comida.'),

(3, 1, 'Tarefa de Exemplo 1', 6,
 'geral');


INSERT INTO alunos VALUES
(1, 0, 5, 5, '1989-08-16', '', NULL, NULL),
(2, 11, 5, 0, NULL, NULL, NULL, NULL),
(3, 13, 5, 0, NULL, NULL, NULL, NULL),
(4, 14, 5, 0, NULL, NULL, NULL, NULL),
(6, 16, 5, 0, NULL, NULL, NULL, NULL);


-- ==========================================
-- ALFABETO LIBRAS
-- ==========================================

INSERT INTO alfabeto (id, letra, imagem_url, ordem) VALUES
(1,'A','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjssULGs4plhKsjdTl1Xk5k4X2aFHDyNugoUfC3dpWI0mw-ZoaFTVVR27kfmmVxxYQess1zmZ3ZNyWjy_XTR8JHLjQIbVONlgn6qLagpjaO6NW39UK-Y3nD-MbpoorbMa8wt6DxqxjQ849-6y32IvETk_ss1WdxNEMt2DhbjollL81W1ZQTuBqweetq/w452-h640/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(1).jpg',1),
(2,'B','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjr0kdf6C87rbtJUW8yY4socWoejnoeQHihN6U0UfkBa3ppnG6msr0szvlF-QvXPUcJ0YqSVm-qeWjS6CJnCrXdIbxUrHO62gumqQ0zDp5OeLp41TUx_CPE9oUrARJSp5M5xha6xilP5Ut48zx3xnSzYE7oLIFfC3pU1dnoNvw2TV_sS9CvMm1pX1p3/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(2).jpg',2),
(3,'C','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgORq5XDYKcIpqlluTy9PO_8WEmwJjSSVH8aeS46DG6sWYOFlDVDsoi79pakw11giaxHgKH6jAxlETGvcXFDCJAxspopwvTDOof6N7SgAE4nprBy19yNsfqUYdq-cle633AaXv8kOVjtLv2mneeFHBJSQC492m8dFeJnyne9i8TzhwWoBxSwPbWcviZ/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(3).jpg',3),
(4,'D','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEirMBPua_xGQ9I2QWj5FpJmQOAcaqnulENdZK9vEya1PTx4PeaxADDPRauWcDO0BILzQv8t-Tyi6HjRV-_qa4-JRZCwxWYy8UUypfmAHDLDp3igA8DNBbu6YMA9-s-pZc-Lwy80VshmpnYQEukCmOb489sp8VK1wVCEAoF9EE7IyxSNX9X5Mmx-Cuys/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(4).jpg',4),
(5,'E','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEigTfeHFJLS7bIIUv87K1TI2MTpjmM5FVVXJ-s4SWpf_yBOG5XMv1bTUFNuUJOHyOEemmQ2s7xVa5PkNjCwqxsNS-slmkO-6Gxcax9sbpv4PlbO_7_GzBLVJhmFwmSMXmZVIAj4dfvl693DCbUptuft6ov3SXHMw7l-b9IggTWJJZr4asq_9dBoD6-l/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(5).jpg',5),
(6,'F','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg2ziOAHIYfYgpq-uo4mCVGsjnil3A2PuAiD1YLqqEk2xKyWyewK-KJSUBo1YvkwKupbUqVHIgrnH2CtGPETJ3xDZYd3QV5niYxaitIBABLzuEkYYVtgwVcw16cXh1huyY_qJrjHNxr1pESzTWCoTUbXbzdwtNyoLIvUlbrMfV1zQUQzQtHu_MaotsZ/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(6).jpg',6),
(7,'G','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEif9fAjrCbyWdoe6uTSZsYRdcBAa809L8oKKqWXWCf9kJGurWlvQkKaRg3u7BK1gSUznv8cjdwjeMZs3up3CLKpcS2Xqb4Rz2SHEAKqnFt_zp3BO7aNsrlR3ezOq_gaGTsxEGClTtu-s3kW77M_VDA8pkpDjof2d8Ws8y5x3QavTUYY1UG9HHfVO_UJ/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(7).jpg',7),
(8,'H','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiKiDjXfVdBeA0y5UKACZrktpAK3DsSnNj8I24i8JufH7dFThRvDz_cfKvgq9M6ekN_L5athYQx29Pk-4BW1D8evuqxH_WRKxgo0NkpUxE3AJ496kQK-CFcfV87JTukYarsm90WWNtEdD4G_Apq1VZBBR1ZBb9VP40f_ia9Np2GUzOlXqad3ihBb-XZ/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(8).jpg',8),
(9,'I','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgbOxOpR2ornadJBpp7wWR2vo7PTykgiBMoEyN0NGDek9_l3wyylhrjAsFkOSSfSPtV_LsyLxYNsXsQqMVna1gGoZkwwPhGDB5Sebx8Xn5iGg8YyMC0kN81dzqFy1D0P6jqzU2TTEdS5luHs_xB55ZCWjJ9GlBjtyu2PI3cmc4ReWOp9kCIZEmX-rHu/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(9).jpg',9),
(10,'J','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjfKi4XC1SOEC-boXAP58DNU7AtBD2vnu0f23n9MN_L4TOmqwZPZhz1_6zrQh_vduiG64aqr-U--xmdsxulWM3L4sNXBi92RN6iSqk8pn21jaa9Y_8hjaSoIH3OnolBxXt90Wfce8IBlwCWst_kv6I740iC6PX9EaBx3b3_0JIxC2MQrnFAb0IMwOtB/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(10).jpg',10),
(11,'K','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj15_JB5p2kiejW7KZtinZZYnpHKTksUzQ3nx9j7ckotqJRk8x1UAQf5otyz6jZ_dlyqkLRgsDjIM5aSyCcY2qqp-_DtAVnP1hH2P9GhI3PaVFo_aG7gxs-CtbaVQOl_QDMtavhMgsn7JyKJTLBN0K8uHBH42iyOZEXG2uE0HLtVc-xqla-Oh19dQk1/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(11).jpg',11),
(12,'L','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgWYG8maYxYvIFhJBEWfCQMjfqDM-GIEZjyfLDLGugLTKuqraFUb2hL6DoC0sl16kuuXRNy0G7aFBbhdIaACGFShqntdd2KoOnE8dsL4tE3vKcVnHel3_NTSodB79VGXur77peWJezjwWRfCV6fxHTBPTXVQWE-jrTqSVk4fW9RIPU2DVvSmtoDZsS4/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(12).jpg',12),
(13,'M','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgIsdzlEXubzkkYzeTuqYNAuaRg8hpJndE-YCOT07gZdC33tO1DyfyiZxZ2JYniU9aFSGNSu1AI68JbSdSSCBjnA-QAS5rEtDoYApaTezpure_AyPHUwz4FihJz8bnc-t3gSraZodg4aae9HbcxzQzw7KKFSYcz8JVW11ekf6Ia1l-k5kwkGudTGEI9/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(13).jpg',13),
(14,'N','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgratS0joAPnTGZRir1J8NO-_k1o73D3wbALBrcRsXmjYRxvjA4TPhnzl0LFmuCKp-lPvt4Xp7afxz5Nvj9gpu-2Ei3zIVRXe8itQcQuB1cvhJsXFTRuF21CP7bsy4Or5-wUuC6g2uAFZFtNi9wksCyqa2hXubgBcSvjbwgM206vt_Ta8MDn74UTSmw/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(14).jpg',14),
(15,'O','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEizmuhALt8OiEzU2-Iy_sPmpmPPlgY-AEzW1MoQxCBUPjD7Rj9FjAdWU49-2gAK9UMJHhkyrXX9ZZuEOYy9guUXsckFNpncgqIh9xbAAKQzAw9YzfLkyvR18nWW_Q-irO-PWIuNQ5KyWylCIeywgwTazL08l3qMssG3r1NAVVCvyArKlWbnyRTaQ2xJ/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(15).jpg',15),
(16,'P','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgj5YkAsU5Nx8v3VKGYsfeUavbXp-o-W5nYSairLowSSF4OqntluOTZJ7qw8uedvB0QgGKCJPCkO63XwlIcDuZ4eXAtutROpXuwM1lKc0FRLYnYMMzl0iNLAQPOzyAsVDMrCR72Ts5yIPB-Aoci2fQhMh2e2RyblaB6B9outDTDbxMx6Lrurk_pvGTf/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(16).jpg',16),
(17,'Q','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEivGDhL8CYkoY9WwybUbr0VXOgf_B8qiV6fxgiAZ3GTY5XaNPUg8Z0A--DGRZw4eeVuZP37t56pK0wsJ0AqJe53IlWychHFkijeaD0nVkiYXVK0j3HW1y14plw84GbjeqcTwxAzTrVJUbmapdbADmk9U1AiAOh7UjK3OhZOdSlGdXCjCTDQhDw-s386/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(17).jpg',17),
(18,'R','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgjCAPDnyh0168oDf1ojLRuWJ9oW8p-TWYFDuKlSuXo1lIS-O8972YHcdYjq35CmH0fltnG67Bo5AwnVz_wYaGGLDBFltX0WgwLBtNl9a-GfjC2lv5Pe6TvkuLnUR2b73LjcFajd4UIWQSwdlO-sOLnUvtpMEwnh8UFriKCuaonUyofI2hNEW8YRMT1/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(18).jpg',18),
(19,'S','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEirj9AbwOsVqy3V8gXEM2EpfBs4Z6GbaO9goMyjeZMfq_bb-YR_UFm9lZFZKlwKPp9ETADy5SFFuwa9YmTTEtvlZOy5RPr4sLkJRMszxRqEv9C6C5iGyl7vAM3qA4BRPfzEtxyVEkKCt4aZnecp2JsvBv-jNaUW--skd2zJveQJIwgcOgmIScQGEBtf/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(19).jpg',19),
(20,'T','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjUrkEhGcwwHcpodLOtU1pYw_XbNFT5y0VxnQp1OwaLcgLYF6C8NjggUKjzGR-l5jckUa9GACN4SXQ0nofH9dMwY_rQl_Wet5Lcs2DVfVRJaRGHMuo2MqCryIBA4wvlkUlrIuK3jKNrYWGUdWlsCrQkArW4decEy0tVUeehRGp9IJLZinMS_sBah3U9/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(20).jpg',20),
(21,'U','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjNJrWLvQFgQS9UUbjIrJFy6Cnx4eUyVhPK8TdoZCn_5rG5MUeFuqfkcPvcRl6usxl3mqbfjSo84vCyZty86HzrOleW--lVUyXECInO3QqU42-xLmnx-HMr2utHY6ABnUN7o1E0R7ziptsVvPxfIzxw3FiP8QHhf5X2UQcAMHuPNM2FfkPp_eetDmdi/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(21).jpg',21),
(22,'V','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiQoL9VmTef9KCsFYvGQmkOoB0UShnp2dY6wt0YcuhaDIsOj5SJsTK4TZTF4WG6QmWItRgEQ23PD1J3i6Z6cSjEn6__U9hAgy9l0hvS3Y3kgrEkT4l-kyJj47ELiQtHsNyi1yKXnrP6GhhoDs6EkQRjKKdSNP_ebk57D0hb5qmmOEsSuCHiHgY9oEYq/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(22).jpg',22),
(23,'W','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjUooF8k6pjo74Vk1GzXFuVwVAPj1XdV30LQxqSd4SUlvRJFxxElj2MW5WdK5zbYNm5OLYUz8HSMypHCXuy6Ua0_DsuowXoSs84ibzp0SRAAmWTXcwWUPSA9ZOiR_QrqFRZafvzGLAmlk5KMNkUjUAZdOWTIAVLAkcyDQbZb1xFTO2tUHUhk1AsIn7/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(23).jpg',23),
(24,'X','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj-3R0p8n1DqY_yhGG2hrzlnx7i-QWaq9Gq_DNEkwrM6Y70XN8RrzeHx0BTNdBRini7hcRDl2Sf4Cn9r9BXs9yzlyhFs20tBIgVgoGro6XBwICedZmRTs7znKr7ZZOhX8SIpu5gxTllv02Cn3N3NgEFZNCzvlEB3uvAWhxbJo0IMaBSqUKNI2UTMQ6G/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(24).jpg',24),
(25,'Y','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgzm6zmWIq6K7REC-2L78UblrakJ6K919L1vKWmi88hpgbIqOCF_dBS7CCOvsqEgkwi7H_Jxv4r5pzVpfffEXUvkKhrXulx4a7TTYQXwGEp8V4hjzYaWyBoePYhEjpyliJTzH4qLBqsZUExlpE5U5uRykWwQQpGIT_KkPX08-wU9UormBYRZilY7VU4/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(25).jpg',25),
(26,'Z','https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgZ6WJcgL2r5wXrFRONzZwBEx0K8kK1pc01IqBQ7uIIBzg1Z_8jLbEdAQ_HSquu9A8BZkfjNcC5KCJJtg9u5M8xRVsj4K9RcX1T6Zb6KrO3PhtgPYQn2GXkPPmwPID3hgCW7TM0mOzFxLs_LsQXQ88bycBz1u2g2YTp3RUX-1urV6vZm1oCF26zZg-E/s1600/alfabeto-em-libras-para-imprimir-colorido-sinais-parede-sala-de-aula-cartaz-cartazes-letras-todas-abc-alfa-alfabetos-lindos%20(26).jpg',26);


-- ==========================================
-- LIÇÕES
-- ==========================================

INSERT INTO licoes VALUES
(1,1,'O Alfabeto Manual',1,0),
(2,1,'Saudações Básicas',2,0),
(3,1,'Números de 1 a 10',3,0),
(4,1,'Cumprimentos',4,0),
(5,1,'Família',5,0),
(6,2,'As Cores',1,0),
(7,2,'Tempo e Clima',2,0),
(8,2,'Alimentos',3,0),
(9,1,'Teste de Fixação',6,0),
(10,1,'Teste',2,0),
(11,1,'Hamlet',1,0),
(12,3,'dias',3,1);


-- ==========================================
-- QUESTÕES
-- ==========================================

INSERT INTO questoes VALUES
(1,'Como se diz \'Olá\' em LIBRAS?','multipla_escolha',9),
(2,'Como é a letra \'A\' em LIBRAS?','multipla_escolha',1),
(3,'Qual a expressão facial mais comum ao sinalizar \'Bom dia\'?','multipla_escolha',2),
(4,'Para expressar QUANTIDADE, como fazemos o número 3 em LIBRAS?','multipla_escolha',3),
(5,'Qual é a combinação de sinais para perguntar \'Tudo bem?\'','multipla_escolha',4),
(6,'Geralmente, o sinal de \'Mãe\' envolve tocar qual parte do corpo?','multipla_escolha',5),
(7,'O sinal da cor \'Amarelo\' é feito passando o dedo indicador em qual região?','multipla_escolha',6),
(8,'Para expressar que está \'Frio\', qual movimento corporal usamos?','multipla_escolha',7),
(9,'Como se sinaliza a palavra \'Água\' em LIBRAS?','multipla_escolha',8),
(10,'Qual é o sinal correto para a cor "Azul" em LIBRAS?','multipla_escolha',6),
(11,'Como se sinaliza a palavra "Quente" em LIBRAS?','multipla_escolha',7),
(12,'Qual é o sinal correto para "Maçã" em LIBRAS?','multipla_escolha',8),
(13,'Associe cada saudação ao seu sinal em LIBRAS.','associacao',1),
(14,'Associe cada sinal ao membro da família em LIBRAS.','associacao',5),
(15,'Relacione cada cor ao seu sinal em LIBRAS.','associacao',6),
(17,'Quantos dedos são levantados para representar o número 5 em LIBRAS?','aberta',3),
(18,'Qual palavra é representada pelo sinal de mão espalmada balançando de um lado para o outro?','aberta',4);


-- ==========================================
-- QUESTÕES DE MÚLTIPLA ESCOLHA
-- ==========================================

INSERT INTO questoes_multipla_escolha VALUES
(1,'Assinale a opção com o sinal de Olá.','texto'),
(2,'Selecione a opção correta','texto'),
(3,'','texto'),
(4,'','texto'),
(5,'','texto'),
(6,'','texto'),
(7,'','texto'),
(8,'','texto'),
(9,'','texto'),
(10,'Qual é o sinal correto para a cor "Azul" em LIBRAS?','texto'),
(11,'Como se sinaliza a palavra "Quente" em LIBRAS?','texto'),
(12,'Qual é o sinal correto para "Maçã" em LIBRAS?','texto');


INSERT INTO opcoes_questao VALUES
(1,1,'Mão fechada balançando','texto',0),
(2,1,'Mão espalmada balançando de um lado pro outro','texto',1),
(3,1,'Dedo indicador apontando pra frente','texto',0),

(4,2,'Mão fechada com polegar encostado na lateral','texto',1),
(5,2,'Mão aberta com os dedos separados','texto',0),
(6,2,'Dedos cruzados','texto',0),

(7,3,'Expressão brava ou séria','texto',0),
(8,3,'Sorriso leve e amigável','texto',1),
(9,3,'Rosto neutro sem emoção','texto',0),

(10,4,'Três dedos em pé (indicador, médio e anelar)','texto',0),
(11,4,'Polegar, indicador e médio esticados','texto',1),
(12,4,'Apontar para 3 coisas','texto',0),

(13,5,'Sinal de \'bom/bem\' seguido de \'joinha\' com expressão interrogativa','texto',1),
(14,5,'Mão aberta passando no rosto duas vezes','texto',0),
(15,5,'Acenar com as duas mãos para cima','texto',0),

(16,6,'Tocar a testa e o peito','texto',0),
(17,6,'Tocar o ombro duas vezes','texto',0),
(18,6,'Passar o polegar e indicador no rosto/queixo + sinal de mulher','texto',1),

(19,7,'Descendo pelo meio do rosto','texto',1),
(20,7,'Girando na ponta do nariz','texto',0),
(21,7,'Batendo no peito','texto',0),

(22,8,'Fazer vento com as mãos na frente do rosto','texto',0),
(23,8,'Tremer os braços recolhidos, batendo os dentes levemente','texto',1),
(24,8,'Esfregar a cabeça com as duas mãos','texto',0),

(25,9,'Bater o dedo indicador e médio (letra L) no queixo','texto',1),
(26,9,'Movimento de levar um copo imaginário até a boca','texto',0),
(27,9,'Agitar a mão aberta de um lado para o outro','texto',0),

(28,10,'Passar o dedo indicador no nariz','texto',0),
(29,10,'Passar o dedo indicador nos lábios','texto',1),
(30,10,'Bater a mão no peito duas vezes','texto',0),
(31,10,'Girar o polegar no queixo','texto',0),

(32,11,'Balançar as mãos rapidamente para os lados','texto',0),
(33,11,'Levantar as mãos abertas simulando vapor subindo','texto',1),
(34,11,'Encolher os ombros e abraçar o próprio corpo','texto',0),
(35,11,'Apontar para o sol com o dedo indicador','texto',0),

(36,12,'Imitar morder algo com a mão em C','texto',0),
(37,12,'Torcer o pulso com o dedo indicador na bochecha','texto',1),
(38,12,'Passar a mão espalmada sobre a cabeça','texto',0),
(39,12,'Juntar as pontas dos dedos e abrir','texto',0);


-- ==========================================
-- QUESTÕES ASSOCIATIVAS
-- ==========================================

INSERT INTO questoes_associativas VALUES
(13),
(14),
(15);


INSERT INTO itens_associativos VALUES
(9,'Polegar e indicador no queixo (lado feminino)','texto','A',14),
(10,'Mãe','texto','B',14),
(11,'Polegar e indicador na testa (lado masculino)','texto','A',14),
(12,'Pai','texto','B',14),
(13,'Dedo médio tocando o próprio ombro','texto','A',14),
(14,'Irmão','texto','B',14),
(15,'Mão em L perto do rosto com movimento suave','texto','A',14),
(16,'Irmã','texto','B',14),

(17,'Indicador descendo pelo meio do rosto','texto','A',15),
(18,'Amarelo','texto','B',15),
(19,'Esfregar as mãos abertas de forma circular','texto','A',15),
(20,'Verde','texto','B',15),
(21,'Dedo indicador nos lábios','texto','A',15),
(22,'Azul','texto','B',15),
(23,'Tocar a ponta do nariz com o indicador','texto','A',15),
(24,'Vermelho','texto','B',15),

(33,'Mão espalmada balançando de lado a lado','texto','A',13),
(34,'Olá','texto','B',13),
(35,'Fecho o polegar em formato de "o" e levanta o dedo mínimo','texto','A',13),
(36,'Oi','texto','B',13),
(37,'Mão espalmada encostadas, puxando para o corpo','texto','A',13),
(38,'Com licença','texto','B',13),
(39,'Mão espalmada tocando ao lado da testa','texto','A',13),
(40,'Obrigado','texto','B',13);


INSERT INTO pares_associativos VALUES
(5,9,10),
(6,11,12),
(7,13,14),
(8,15,16),
(9,17,18),
(10,19,20),
(11,21,22),
(12,23,24),
(17,33,34),
(18,35,36),
(19,37,38),
(20,39,40);


-- ==========================================
-- QUESTÕES ABERTAS
-- ==========================================

INSERT INTO questoes_abertas VALUES
(17,'5',
 'Quantos dedos são levantados para representar o número 5 em LIBRAS?',
 'texto'),

(18,'Olá',
 'Qual palavra é representada pelo sinal de mão espalmada balançando de um lado para o outro?',
 'texto');


-- ==========================================
-- PROGRESSO
-- ==========================================

INSERT INTO progresso_licoes VALUES
(1,1,1,1,'2026-09-04 18:48:56',0),
(2,1,2,1,'2026-09-04 18:52:11',0),
(4,1,11,1,'2026-08-26 15:51:18',0),
(5,1,10,1,'2026-09-04 18:52:16',0),
(6,1,3,1,'2026-08-28 16:43:16',0),
(7,1,4,1,'2026-08-28 17:01:30',0),
(8,1,5,1,'2026-08-28 17:01:41',0),
(9,1,9,1,'2026-08-28 17:01:51',0),
(10,1,6,1,'2026-08-28 17:05:11',0),
(12,14,1,1,'2026-08-31 18:35:20',0),
(13,2,1,1,'2026-09-04 19:44:59',0),
(14,2,11,1,'2026-09-04 13:02:57',0),
(15,2,2,1,'2026-09-04 13:08:10',0),
(16,2,10,1,'2026-09-03 22:03:01',0),
(17,2,3,1,'2026-09-03 23:48:45',0);
