<?php
require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/AlfabetoController.php");

$authCtrl = new AuthController();
$authCtrl->exigirLogin();
$usuarioLogado = $authCtrl->getUsuarioLogado();

$alfabetoCtrl = new AlfabetoController();
$letras = $alfabetoCtrl->listar();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alfabeto em Libras - EntreGestos</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="../../public/css/global.css">
   <link rel="stylesheet" href="../../public/css/alfabeto.css">
</head>

<body>

    <!-- Header -->
    <header class="app-header">
        <a href="trilha.php" class="logo">EntreGestos</a>
        <h1>Alfabeto em Libras</h1>
        <a href="trilha.php" class="back-link">← Voltar</a>
    </header>

    <!-- Main -->
    <main class="main-content">

        <div class="page-intro">
            <h2>Aprenda o alfabeto</h2>
            <p>Clique em uma letra para assistir ao vídeo do sinal.</p>
        </div>

        <div class="alfabeto-grid">
            <?php foreach ($letras as $item): ?>
                <div class="letra-card">
                    <div class="letra-titulo"><?= htmlspecialchars($item->getLetra()) ?></div>

                    <?php if ($item->getVideoId()): ?>
                        <div class="video-card"
                             onclick="abrirVideo('<?= htmlspecialchars(addslashes($item->getLetra())) ?>', '<?= htmlspecialchars(addslashes($item->getVideoId())) ?>')">
                            <div class="play-button">▶</div>
                            <div class="video-text">Assistir sinal</div>
                        </div>
                    <?php else: ?>
                        <div class="video-card sem-video">
                            <div class="video-indisponivel">Vídeo em breve</div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>

            <?php if (empty($letras)): ?>
                <p style="grid-column: 1 / -1; text-align:center; color: var(--text-muted);">
                    Nenhuma letra cadastrada ainda.
                </p>
            <?php endif; ?>
        </div>

    </main>

    <!-- Janela do vídeo -->
    <div class="video-modal" id="videoModal" onclick="fecharAoClicarFora(event)">
        <div class="video-modal-conteudo">

            <button class="fechar-video" onclick="fecharVideo()">×</button>

            <div class="video-modal-titulo" id="videoTitulo">Letra em Libras</div>

            <div class="video-frame">
                <iframe
                    id="videoIframe"
                    src=""
                    title="Vídeo em Libras"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowfullscreen>
                </iframe>
            </div>

            <div class="video-creditos">
                Vídeo por: <a href="https://www.youtube.com/@incluirtecnologia" target="_blank" rel="noopener noreferrer">Canal Saber Mais</a>
            </div>

        </div>
    </div>

    <!-- Footer -->
    <footer class="app-footer">
        <p>EntreGestos — Aprendendo Libras de forma divertida</p>
        <p class="creditos">
            Vídeos cedidos pelo canal <a href="https://www.youtube.com/@incluirtecnologia" target="_blank" rel="noopener noreferrer">Saber Mais</a>
        </p>
    </footer>

    <script src="../../public/JS/alfabeto.js"></script>

</body>

</html>