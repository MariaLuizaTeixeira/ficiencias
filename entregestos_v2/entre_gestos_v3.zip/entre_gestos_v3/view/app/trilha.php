<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once(__DIR__ . "/../../util/config.php");


require_once(__DIR__ . "/../../controller/AuthController.php");
require_once(__DIR__ . "/../../controller/LicaoController.php");
require_once(__DIR__ . "/../../controller/SecaoController.php");
require_once(__DIR__ . "/../../dao/ProgressoDAO.php");

$authCtrl = new AuthController();
$authCtrl->exigirLogin();
$alunoId = $authCtrl->getUsuarioLogadoId();
$usuarioLogado = $authCtrl->getUsuarioLogado();

$licaoCtrl = new LicaoController();
$secaoCtrl = new SecaoController();
$progressoDao = new ProgressoDAO();

$licoesConcluidas = $progressoDao->getLicoesConcluidas($alunoId);

// Get all lessons and sections
$todasLicoes = $licaoCtrl->listar();
$secoes = $secaoCtrl->listar();

// Group lessons by section
$trilha = [];
foreach ($secoes as $secao) {
    $trilha[$secao->getId()] = [
        'secao' => $secao,
        'licoes' => []
    ];
}

$isLocked = false;
foreach ($todasLicoes as $licao) {
    $licaoId = $licao->getId();
    $completada = in_array($licaoId, $licoesConcluidas);

    if (!$isLocked) {
        if (!$completada) {
            $status = 'lesson-current';
            $isLocked = true; // A partir daqui, as próximas estarão bloqueadas
        } else {
            $status = 'lesson-unlocked';
        }
    } else {
        $status = 'lesson-locked';
    }

    $licao->status_calculado = $status;

    if (isset($trilha[$licao->getSecaoId()])) {
        $trilha[$licao->getSecaoId()]['licoes'][] = $licao;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aprender LIBRAS - EntreGestos</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700;800;900&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="../../public/css/global.css">
   <link rel="stylesheet" href="../../public/css/trilha.css">
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">EntreGestos</div>

        <div style="text-align: center; margin-bottom: 30px;">
            <div style="font-weight: 900; color: var(--text-main); font-size: 18px;">
                Olá, <?= htmlspecialchars(explode(' ', $usuarioLogado['nome_completo'])[0]) ?>!
            </div>
            <div style="font-size: 14px; font-weight: 700; color: var(--text-muted); text-transform: capitalize;">
                <?= htmlspecialchars($usuarioLogado['perfil']) ?>
            </div>
        </div>

        <a href="#" class="nav-link active">
            <span class="nav-icon"></span> Aprender
        </a>
        <a href="#" class="nav-link">
            <span class="nav-icon" style="background:#ffc800;"></span> Conquistas
        </a>
        <a href="#" class="nav-link">
            <span class="nav-icon" style="background:#ff4b4b;"></span> Perfil
        </a>

        <a href="<?= BASE_URL ?>/view/app/alfabeto.php" class="nav-link">
            <span class="nav-icon" style="background:#ff4b4b;"></span> Alfabeto
        </a>

        <?php if ($usuarioLogado['perfil'] === 'administrador'): ?>
            <a href="../admin/dashboard.php" class="nav-link">
                <span class="nav-icon" style="background:#777;"></span> Admin (CRUDs)
            </a>
        <?php endif; ?>

        <a href="../auth/logout.php" class="nav-link" style="margin-top: auto; color: var(--red-main);">
            <span class="nav-icon" style="background:#ffdfe0;"></span> Sair
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="path-container">

            <?php
            foreach ($trilha as $item):
                $secao = $item['secao'];
                $licoes = $item['licoes'];
            ?>

                <div class="section-header">
                    <h2>Unidade <?= $secao->getOrdem() ?></h2>
                    <p><?= htmlspecialchars($secao->getTitulo()) ?></p>
                </div>

                <div class="timeline">
                    <div class="timeline-line"></div>

                    <?php foreach ($licoes as $index => $licao):
                        $btnClass = $licao->status_calculado; // lesson-locked, lesson-unlocked, lesson-current
                        $locked = ($btnClass === 'lesson-locked');

                        // Alterna entre esquerda e direita
                        $sideClass = ($index % 2 == 0) ? 'item-left' : 'item-right';
                    ?>

                        <div class="timeline-item <?= $sideClass ?> <?= $btnClass ?>">
                            <div class="timeline-dot"></div>

                            <button class="timeline-card"
                                <?= $locked && $btnClass !== 'lesson-current' ? 'disabled' : '' ?>
                                onclick="if(!this.disabled) window.location.href='licao.php?id=<?= $licao->getId() ?>'">

                                <div class="card-icon">
                                    <?php if ($btnClass === 'lesson-locked'): ?>
                                        🔒
                                    <?php elseif ($btnClass === 'lesson-current'): ?>
                                        ▶
                                    <?php else: ?>
                                        ★
                                    <?php endif; ?>
                                </div>

                                <div class="card-content">
                                    <div class="card-title">Lição <?= $licao->getOrdem() ?></div>
                                    <div class="card-subtitle"><?= htmlspecialchars($licao->getTitulo()) ?></div>
                                </div>

                                <div class="card-stars">
                                    <?php if ($btnClass === 'lesson-unlocked'): ?>
                                        ★★★
                                    <?php elseif ($btnClass === 'lesson-current'): ?>
                                        ☆☆☆
                                    <?php else: ?>

                                    <?php endif; ?>
                                </div>
                            </button>
                        </div>

                    <?php endforeach; ?>
                </div>

            <?php endforeach; ?>

            <?php if (empty($trilha)): ?>
                <div style="text-align: center; color: var(--text-muted); margin-top: 50px;">
                    <h2>Nenhuma lição cadastrada ainda!</h2>
                    <p>Vá no Admin e crie Cursos, Seções e Lições.</p>
                </div>
            <?php endif; ?>

        </div>
    </div>

</body>

</html>