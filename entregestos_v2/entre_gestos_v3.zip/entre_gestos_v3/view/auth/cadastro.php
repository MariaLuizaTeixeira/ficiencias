<?php
require_once(__DIR__ . "/../../controller/AuthController.php");

$authController = new AuthController();

if ($authController->estaLogado()) {
    header("Location: ../app/trilha.php");
    exit;
}

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';

    if ($senha !== $confirmar_senha) {
        $erro = 'Uai, as senhas não tão batendo! Dá uma conferida aí, sô.';
    } else {
        $resultado = $authController->cadastrar($nome, $email, $senha);

        if (empty($resultado)) {
            header("Location: ../app/trilha.php");
            exit;
        } else {
            $erro = $resultado;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - EntreGestos</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700;800;900&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="../../public/css/global.css">
   <link rel="stylesheet" href="../../public/css/cadastro.css">
  
</head>

<body>

    <div class="split-layout">
        <!-- Esquerda: Capivara / Mensagem -->
        <div class="left-side">
            <div class="mascote">
                <img src="<?= BASE_URL ?>/view/assets/imagens/capivara.png" alt="Capivara">
            </div>
            <h1>Aprenda Libras com a Capivara!</h1>
            <p>Sua jornada de aprendizado começa aqui 🌱</p>
        </div>

        <!-- Direita: Card de Cadastro -->
        <div class="right-side">
            <div class="login-card">
                <h2>Criar sua conta</h2>
                <p>Venha fazer parte dessa comunidade</p>

                <?php if (!empty($erro)): ?>
                    <div class="error-message">
                        <?= htmlspecialchars($erro) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label>Nome Completo</label>
                        <div class="input-wrapper">
                            <span class="input-icon">👤</span>
                            <input type="text" name="nome" class="form-control" placeholder="Seu Nome" required autofocus>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <div class="input-wrapper">
                            <span class="input-icon">✉️</span>
                            <input type="email" name="email" class="form-control" placeholder="seu@email.com" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Senha</label>
                        <div class="input-wrapper">
                            <span class="input-icon">🔒</span>
                            <input type="password" name="senha" class="form-control" placeholder="••••••••" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Confirme a Senha</label>
                        <div class="input-wrapper">
                            <span class="input-icon">🔑</span>
                            <input type="password" name="confirmar_senha" class="form-control" placeholder="••••••••" required>
                        </div>
                    </div>

                    <button type="submit" class="btn-main">Cadastrar</button>
                </form>

                <div class="divider"></div>

                <div class="footer-link">
                    Já tem uma conta? <a href="login.php">Fazer Login</a>
                </div>
            </div>
        </div>
    </div>

</body>

</html>