<?php

/**
 * Includes o layout do header da sidebar do admin.
 * $activePage deve ser definida antes de incluir este arquivo.
 * Ex: $activePage = 'usuarios';
 */

require_once __DIR__ . "/../../../util/config.php";
require_once __DIR__ . "/../../../controller/AuthController.php";

$auth = new AuthController();
$auth->exigirLogin();
$user = $auth->getUsuarioLogado();
if ($user['perfil'] !== 'administrador') {
    die("Acesso negado! Exclusivo para administradores.");
}

$paginas = [
    'dashboard'  => ['label' => 'Dashboard',   'icon' => '🏠', 'url' => BASE_URL . '/view/admin/dashboard.php',            'color' => '#1cb0f6'],
    'usuarios'   => ['label' => 'Usuários',    'icon' => '👤', 'url' => BASE_URL . '/view/admin/usuarios/listar.php',      'color' => '#ce82ff'],
    'cursos'     => ['label' => 'Cursos',      'icon' => '📚', 'url' => BASE_URL . '/view/admin/cursos/listar.php',        'color' => '#1cb0f6'],
    'secoes'     => ['label' => 'Seções',      'icon' => '📂', 'url' => BASE_URL . '/view/admin/secoes/listar.php',        'color' => '#ff9600'],
    'licoes'     => ['label' => 'Lições',      'icon' => '🎯', 'url' => BASE_URL . '/view/admin/licoes/listar.php',        'color' => '#58cc02'],
    'atividades' => ['label' => 'Atividades',  'icon' => '✏️', 'url' => BASE_URL . '/view/admin/atividades/listar.php',   'color' => '#ce82ff'],
];
$activePage = $activePage ?? 'dashboard';

// Endereço da raiz do projeto, calculado a partir da URL real da página.
// Ex.: /ProjetoEntreGestos/entre_gestos_v3  (funciona com qualquer host/porta)
$webBase = preg_replace('#/view/admin/.*$#', '', str_replace('\\', '/', $_SERVER['SCRIPT_NAME']));
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'Admin') ?> - EntreGestos</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= $webBase ?>/public/css/global.css">
    <link rel="stylesheet" href="<?= $webBase ?>/public/css/admin.css">
    <link rel="stylesheet" href="<?= $webBase ?>/public/css/formularios.css">
    <?php foreach (($extraCss ?? []) as $cssExtra): ?>
    <link rel="stylesheet" href="<?= $webBase ?>/public/css/<?= htmlspecialchars($cssExtra) ?>">
    <?php endforeach; ?>
</head>

<body>
    <div class="sidebar">
        <div class="sidebar-logo">EntreGestos</div>
        <div class="sidebar-badge">PAINEL ADMIN</div>
        <div class="sidebar-divider"></div>

        <?php foreach ($paginas as $key => $pg): ?>
            <a href="<?= $pg['url'] ?>" class="nav-link <?= $activePage === $key ? 'active' : '' ?>">
                <span class="nav-icon"><?= $pg['icon'] ?></span>
                <?= $pg['label'] ?>
            </a>
        <?php endforeach; ?>

        <div class="nav-link-bottom">
            <div class="sidebar-divider"></div>
            <a href="<?= BASE_URL ?>/view/app/trilha.php" class="back-link">
                <span class="nav-icon">🎮</span> Ver App
            </a>
        </div>
    </div>

    <div class="main-content">