-- Execute UMA vez no phpMyAdmin (aba SQL) com o banco 'entregestos' selecionado.
-- Adiciona o campo Título nas atividades (questões já cadastradas ficam com título vazio).
ALTER TABLE questoes ADD COLUMN titulo varchar(150) NOT NULL DEFAULT '' AFTER id;
