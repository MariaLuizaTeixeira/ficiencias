const tipoQuestao = LICAO_CONFIG.tipoQuestao;
let selectedBtn = null;

function selectOption(btn) {
    document.querySelectorAll('.option-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selectedBtn = btn;
    document.getElementById('checkBtn').classList.add('active');
    document.getElementById('checkBtn').disabled = false;
}

function checkInput() {
    const val = document.getElementById('resposta_aberta').value.trim();
    const btn = document.getElementById('checkBtn');
    if (val.length > 0) {
        btn.classList.add('active');
        btn.disabled = false;
    } else {
        btn.classList.remove('active');
        btn.disabled = true;
    }
}

function checkAssoc() {
    const selects = document.querySelectorAll('.assoc-right');
    let allFilled = true;
    selects.forEach(s => {
        if (s.value === "") allFilled = false;
    });
    const btn = document.getElementById('checkBtn');
    if (allFilled) {
        btn.classList.add('active');
        btn.disabled = false;
    } else {
        btn.classList.remove('active');
        btn.disabled = true;
    }
}

function checkAnswer() {
    const checkBtn  = document.getElementById('checkBtn');
    if (checkBtn.innerText === 'CONTINUAR' || checkBtn.innerText === 'PRÓXIMA') {
        checkBtn.onclick();
        return;
    }
    if (checkBtn.disabled) return;

    let isCorrect = false;

    if (tipoQuestao === 'multipla_escolha') {
        if (!selectedBtn) return;
        isCorrect = selectedBtn.getAttribute('data-correct') === '1';
        if (isCorrect) {
            selectedBtn.classList.add('correct');
            selectedBtn.classList.remove('selected');
        } else {
            selectedBtn.classList.add('wrong');
            selectedBtn.classList.remove('selected');
            setTimeout(() => {
                selectedBtn.classList.remove('wrong');
                selectedBtn = null;
                checkBtn.classList.remove('active');
            }, 2000);
        }
    } else if (tipoQuestao === 'aberta') {
        const answer = document.getElementById('resposta_aberta').value.trim().toLowerCase();
        const correct = document.getElementById('correct_answer').value.trim().toLowerCase();
        isCorrect = (answer === correct);
        const inputEl = document.getElementById('resposta_aberta');
        if (isCorrect) {
            inputEl.style.borderColor = 'var(--green-main)';
            inputEl.style.color = 'var(--green-shadow)';
            inputEl.disabled = true;
        } else {
            inputEl.style.borderColor = '#ea2b2b';
            inputEl.style.color = '#ea2b2b';
            setTimeout(() => {
                inputEl.style.borderColor = '#e5e5e5';
                inputEl.style.color = '#3c3c3c';
                checkBtn.classList.remove('active');
                checkBtn.disabled = true;
            }, 2000);
        }
    } else if (tipoQuestao === 'associacao') {
        const rows = document.querySelectorAll('.assoc-row');
        isCorrect = true;
        rows.forEach(row => {
            const select = row.querySelector('.assoc-right');
            const correctVal = row.getAttribute('data-correct');
            if (select.value !== correctVal) {
                isCorrect = false;
                select.style.borderColor = '#ea2b2b';
                select.style.color = '#ea2b2b';
                setTimeout(() => {
                    select.style.borderColor = '#e5e5e5';
                    select.style.color = '#3c3c3c';
                    select.value = "";
                    checkBtn.classList.remove('active');
                    checkBtn.disabled = true;
                }, 2000);
            } else {
                select.style.borderColor = 'var(--green-main)';
                select.style.color = 'var(--green-shadow)';
                select.disabled = true;
            }
        });
    }

    const feedback  = document.getElementById('feedback');
    const footer    = document.getElementById('footer');

    if (isCorrect) {
        footer.style.backgroundColor = '#d7ffb8';
        footer.style.borderColor     = '#d7ffb8';
        feedback.style.display       = 'block';
        feedback.style.color         = 'var(--green-shadow)';
        feedback.innerText           = '✓ Mandou bem!';

        if (LICAO_CONFIG.proximaUrl) {
            checkBtn.innerText = 'PRÓXIMA';
            checkBtn.onclick = function() {
                window.location.href = LICAO_CONFIG.proximaUrl;
            };
        } else {
            checkBtn.innerText = 'CONTINUAR';
            checkBtn.onclick = function() {
                window.location.href = LICAO_CONFIG.concluirUrl;
            };
        }

        document.querySelector('.progress-fill').style.width = LICAO_CONFIG.progressoPercentual + '%';
    } else {
        footer.style.backgroundColor = '#ffdfe0';
        footer.style.borderColor     = '#ffdfe0';
        feedback.style.display       = 'block';
        feedback.style.color         = '#ea2b2b';
        feedback.innerText           = '✗ Incorreto. Tente novamente!';
        setTimeout(() => {
            footer.style.backgroundColor = 'white';
            footer.style.borderColor     = '#e5e5e5';
            feedback.style.display       = 'none';
        }, 2000);
    }
}
