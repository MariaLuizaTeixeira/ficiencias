function abrirVideo(letra, videoId) {
    const modal = document.getElementById("videoModal");
    const iframe = document.getElementById("videoIframe");
    const titulo = document.getElementById("videoTitulo");

    titulo.textContent = "Letra " + letra + " em Libras";
    iframe.src = "https://www.youtube.com/embed/" + videoId + "?autoplay=1&controls=1";

    modal.classList.add("aberto");
}

function fecharVideo() {
    const modal = document.getElementById("videoModal");
    const iframe = document.getElementById("videoIframe");

    iframe.src = "";
    modal.classList.remove("aberto");
}

function fecharAoClicarFora(event) {
    if (event.target === document.getElementById("videoModal")) {
        fecharVideo();
    }
}

document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') fecharVideo();
});
