<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "localhost");
define("DB_NAME", "entregestos");
define("DB_USER", "root");
define("DB_PASSWORD", "");   

define("AMB_DEV", true);

define("UPLOAD_PATH", __DIR__ . "/../public/");


define("BASE_URL", "http://localhost/ProjetoEntreGestos/entre_gestos_v3");
